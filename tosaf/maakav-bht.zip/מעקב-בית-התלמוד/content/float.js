// float.js — "מעקב" צף בכל אתר (בקשת יוסף, 18/10/2026 — קודם רק ב-Gmail, ובאותו יום: "שהבועה תהיה
// תמיד"): בועה קטנה בפינת הדף, ולחיצה
// פותחת חלונית צפה עם אותו חלון של התוסף (popup.html?embed=1 בתוך iframe — עם כל ההרשאות
// של התוסף, אותה כניסה ואותם נתונים). הבועה והחלונית נגררות, והמיקום נשמר.
// Alt+M פותח וסוגר. אפשר להסתיר את הבועה מהתפריט ⋮ שבתוך התוסף ("בועה צפה"). דפי chrome:// ודף
// "כרטיסייה חדשה" לא מאפשרים לאף תוסף להוסיף בהם משהו — שם הבועה לא תופיע (הכפתור בסרגל כן).
/* global INSTANCES */
(function () {
  'use strict';
  if (window.top !== window || document.getElementById('maakav-float')) return;

  var cfg = INSTANCES[Object.keys(INSTANCES)[0]];
  var COLOR = cfg.color || '#2f6f6b';
  var BUB = 52, PW = 420, BAR = 30;
  var st = { bub: { right: 24, bottom: 24 }, panel: null, open: false };

  var host = document.createElement('div');
  host.id = 'maakav-float';
  host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483000';
  var root = host.attachShadow({ mode: 'open' });
  var ic = function (d) { return '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>'; };
  root.innerHTML = '<style>' +
    ':host{all:initial}' +
    '*{box-sizing:border-box;font-family:"Segoe UI",Arial,sans-serif}' +
    '.bub{position:fixed;width:' + BUB + 'px;height:' + BUB + 'px;border-radius:50%;border:0;cursor:pointer;color:#fff;font-weight:800;font-size:22px;' +
      'background:linear-gradient(160deg,' + COLOR + ',color-mix(in srgb,' + COLOR + ' 75%,#000));box-shadow:0 4px 14px rgba(0,0,0,.28),0 0 0 3px rgba(255,255,255,.9);' +
      'display:grid;place-items:center;transition:transform .12s;user-select:none;touch-action:none}' +
    '.bub:hover{transform:scale(1.06)}.bub.drag{transition:none;cursor:grabbing}' +
    '.badge{position:absolute;top:-3px;right:-3px;min-width:19px;height:19px;padding:0 5px;border-radius:10px;background:#e5484d;color:#fff;font-size:11px;font-weight:700;line-height:19px;text-align:center;box-shadow:0 0 0 2px #fff}' +
    '.badge:empty{display:none}' +
    '.panel{position:fixed;width:' + PW + 'px;border-radius:14px;overflow:hidden;background:#f4f6f5;box-shadow:0 18px 50px rgba(0,0,0,.32),0 0 0 1px rgba(0,0,0,.08);display:flex;flex-direction:column}' +
    '.panel[hidden]{display:none}' +
    '.bar{height:' + BAR + 'px;flex:none;display:flex;align-items:center;gap:2px;padding:0 6px 0 10px;background:color-mix(in srgb,' + COLOR + ' 82%,#000);color:#fff;cursor:grab;user-select:none;direction:rtl}' +
    '.bar.drag{cursor:grabbing}' +
    '.t{flex:1;font-size:12.5px;font-weight:600;opacity:.92}' +
    '.b{width:26px;height:24px;border:0;border-radius:6px;background:transparent;color:#fff;cursor:pointer;display:grid;place-items:center;opacity:.85}' +
    '.b:hover{background:rgba(255,255,255,.18);opacity:1}' +
    'iframe{border:0;width:100%;flex:1;display:block;background:#f4f6f5}' +
    '.shield{position:absolute;inset:' + BAR + 'px 0 0 0;display:none}.panel.dragging .shield{display:block}' +
    '</style>' +
    '<button class="bub" title="מעקב · ' + (cfg.short || cfg.name) + ' (Alt+M)">מ<span class="badge"></span></button>' +
    '<div class="panel" hidden><div class="bar"><span class="t">מעקב · ' + (cfg.short || cfg.name) + '</span>' +
      '<button class="b full" title="פתיחה בחלון גדול">' + ic('<path d="M14 4h6v6"/><path d="M20 4l-8 8"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>') + '</button>' +
      '<button class="b min" title="מזעור (Alt+M)">' + ic('<path d="M6 12h12"/>') + '</button>' +
    '</div><div class="shield"></div></div>';
  var bub = root.querySelector('.bub'), badge = root.querySelector('.badge'), panel = root.querySelector('.panel');
  var bar = root.querySelector('.bar'), frame = null;
  // ב-Gmail (יוסף, 19/10: "ממש בתוך ג'ימייל, ליד 'אימייל חדש'"): כפתור "מעקב" מתחת לכפתור כתיבת המייל, במקום הבועה.
  // הכפתור של Gmail מזוהה לפי gh="cm" (יציב שנים, בניגוד לשמות המחלקות). לא נמצא → הבועה נשארת.
  var GMAIL = location.hostname === 'mail.google.com', gb = null, lastFeed = {};

  function store(keys) { return new Promise(function (r) { try { chrome.storage.local.get(keys, r); } catch (e) { r({}); } }); }
  function save(obj) { try { chrome.storage.local.set(obj); } catch (e) { /* התוסף רוענן — הדף צריך רענון */ } }
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

  function placeBubble() {
    st.bub.right = clamp(st.bub.right, 4, innerWidth - BUB - 4);
    st.bub.bottom = clamp(st.bub.bottom, 4, innerHeight - BUB - 4);
    bub.style.right = st.bub.right + 'px'; bub.style.bottom = st.bub.bottom + 'px';
  }
  function panelHeight() { return Math.min(600 + BAR, innerHeight - 16); }
  function placePanel() {
    var h = panelHeight();
    if (!st.panel) {
      // ברירת מחדל: מעל הבועה, מיושר לצד שלה
      var bx = innerWidth - st.bub.right - BUB, by = innerHeight - st.bub.bottom - BUB;
      var left = bx + BUB / 2 > innerWidth / 2 ? bx + BUB - PW : bx;
      st.panel = { left: left, top: by - h - 10 };
    }
    st.panel.left = clamp(st.panel.left, 8, innerWidth - PW - 8);
    st.panel.top = clamp(st.panel.top, 8, Math.max(8, innerHeight - h - 8));
    panel.style.left = st.panel.left + 'px'; panel.style.top = st.panel.top + 'px'; panel.style.height = h + 'px';
  }

  function toggle(force) {
    st.open = force == null ? !st.open : force;
    if (st.open && !frame) {
      // נטען רק בפתיחה הראשונה (לא מאט את הדף), ונשאר חי כשממזערים — כדי לא לאבד מה שהוקלד.
      var url;
      try { url = chrome.runtime.getURL('popup.html?embed=1'); }
      catch (e) {   // התוסף רוענן מאז שהדף נפתח — הקשר הישן מת
        var msg = document.createElement('div');
        msg.style.cssText = 'padding:24px;font:15px "Segoe UI",Arial,sans-serif;direction:rtl;text-align:center;color:#1d2726';
        msg.textContent = 'התוסף עודכן. יש לרענן את הדף (F5) ואז ללחוץ שוב על הבועה.';
        panel.appendChild(msg); panel.hidden = false; placePanel(); st.open = true; return;
      }
      frame = document.createElement('iframe');
      frame.src = url;
      frame.setAttribute('allow', 'clipboard-write');
      frame.title = 'מעקב';
      panel.appendChild(frame);
    }
    panel.hidden = !st.open;
    if (st.open) { placePanel(); setTimeout(function () { try { frame.focus(); } catch (e) { /* */ } }, 50); }
  }

  // גרירה: מעל 4 פיקסלים = גרירה, אחרת לחיצה
  function dragger(el, onMove, onEnd, onClick) {
    el.addEventListener('pointerdown', function (e) {
      if (e.button !== 0 || e.target.closest('.b')) return;
      var sx = e.clientX, sy = e.clientY, moved = false;
      el.setPointerCapture(e.pointerId);
      function mv(ev) {
        var dx = ev.clientX - sx, dy = ev.clientY - sy;
        if (!moved && Math.abs(dx) + Math.abs(dy) < 5) return;
        if (!moved) { moved = true; el.classList.add('drag'); panel.classList.add('dragging'); }
        onMove(dx, dy); sx = ev.clientX; sy = ev.clientY;
      }
      function up() {
        el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up);
        el.classList.remove('drag'); panel.classList.remove('dragging');
        if (moved) onEnd(); else if (onClick) onClick();
      }
      el.addEventListener('pointermove', mv); el.addEventListener('pointerup', up);
    });
  }
  dragger(bub, function (dx, dy) { st.bub.right -= dx; st.bub.bottom -= dy; placeBubble(); },
    function () { save({ floatBub: st.bub }); }, function () { toggle(); });
  dragger(bar, function (dx, dy) { st.panel.left += dx; st.panel.top += dy; placePanel(); },
    function () { st.dragged = true; save({ floatPanel: st.panel }); });
  root.querySelector('.min').onclick = function () { toggle(false); };
  root.querySelector('.full').onclick = function () { window.open(chrome.runtime.getURL('popup.html?full=1'), '_blank'); };
  document.addEventListener('keydown', function (e) {
    if (e.altKey && !e.ctrlKey && (e.code === 'KeyM')) { e.preventDefault(); e.stopPropagation(); toggle(); }
  }, true);
  addEventListener('message', function (e) {
    if (frame && e.source === frame.contentWindow && e.data && e.data.maakav === 'toggle') toggle(false);
  });
  addEventListener('resize', function () { placeBubble(); if (st.open) placePanel(); });

  function gmailButton() {
    if (gb && gb.host.isConnected) return;
    var cm = document.querySelector('[gh="cm"]');
    var wrap = cm && cm.parentElement, holder = wrap && wrap.parentElement;
    if (!holder) { bub.style.display = ''; return; }      // Gmail עוד נטען / מבנה שונה — הבועה נשארת
    var h = document.createElement('div');
    h.id = 'maakav-gmail-btn';
    h.style.cssText = 'all:initial;display:block';
    var sr = h.attachShadow({ mode: 'open' });
    sr.innerHTML = '<style>' +
      '*{box-sizing:border-box}' +
      '.g{position:relative;display:inline-flex;align-items:center;gap:10px;height:42px;margin:6px 8px 8px;padding:0 16px 0 12px;border:0;border-radius:16px;cursor:pointer;' +
        'background:color-mix(in srgb,' + COLOR + ' 13%,#fff);color:color-mix(in srgb,' + COLOR + ' 85%,#000);font:500 14px "Google Sans",Roboto,"Segoe UI",Arial,sans-serif;' +
        'box-shadow:0 1px 2px rgba(60,64,67,.15);transition:box-shadow .15s,background .15s;direction:rtl}' +
      '.g:hover{box-shadow:0 1px 3px rgba(60,64,67,.3),0 4px 8px rgba(60,64,67,.15);background:color-mix(in srgb,' + COLOR + ' 20%,#fff)}' +
      '.m{width:26px;height:26px;border-radius:8px;display:grid;place-items:center;flex:none;color:#fff;font-weight:800;font-size:15px;background:' + COLOR + '}' +
      '.badge{position:absolute;top:-4px;left:-4px;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:#d93025;color:#fff;font-size:11px;font-weight:700;line-height:18px;text-align:center}' +
      '.badge:empty{display:none}' +
      '.g.mini{width:48px;height:48px;padding:0;justify-content:center;margin:6px 4px}.g.mini .t{display:none}' +
      '</style><button class="g" title="מעקב · ' + (cfg.short || cfg.name) + ' (Alt+M)"><span class="m">מ</span><span class="t">מעקב</span><span class="badge"></span></button>';
    holder.insertBefore(h, wrap.nextSibling);
    gb = { host: h, btn: sr.querySelector('.g'), badge: sr.querySelector('.badge'), cm: cm };
    gb.btn.onclick = function () {
      // ליד הכפתור, אלא אם המשתמש כבר גרר את החלון למקום משלו
      if (!st.dragged) {
        var r = gb.btn.getBoundingClientRect();
        var rtl = getComputedStyle(document.body).direction === 'rtl';
        st.panel = { left: rtl ? r.left - PW - 12 : r.right + 12, top: r.top - 6 };
      }
      toggle();
    };
    var fit = function () { gb.btn.classList.toggle('mini', gb.cm.offsetWidth > 0 && gb.cm.offsetWidth < 100); };
    try { new ResizeObserver(fit).observe(cm); } catch (e) { /* */ }
    fit();
    paintBadge(lastFeed);
    bub.style.display = 'none';
  }

  function paintBadge(d) {
    var f = (d.feedState || {})[cfg.id] || {};
    var n = f.unread || 0;
    badge.textContent = n ? (n > 99 ? '99+' : String(n)) : '';
    if (gb) gb.badge.textContent = badge.textContent;
    lastFeed = d;
  }
  function applyPrefs(d) {
    var p = d.prefs || {};
    host.style.display = p.gmailFloat === false ? 'none' : '';
  }
  // החלון לא נפתח לבד בכל דף חדש — רק בלחיצה (קודם מצב 'פתוח' נשמר ונפתח בכל לשונית).
  store(['floatBub', 'floatPanel', 'feedState', 'prefs']).then(function (d) {
    if (d.floatBub) st.bub = d.floatBub;
    if (d.floatPanel) { st.panel = d.floatPanel; st.dragged = true; }
    placeBubble(); paintBadge(d); applyPrefs(d);
    (document.body || document.documentElement).appendChild(host);
    if (GMAIL) { gmailButton(); setInterval(gmailButton, 1500); }
  });
  try {
    chrome.storage.onChanged.addListener(function (ch) {
      if (ch.feedState) paintBadge({ feedState: ch.feedState.newValue });
      if (ch.prefs) applyPrefs({ prefs: ch.prefs.newValue });
    });
  } catch (e) { /* */ }
})();
