// popup.js — הליבה של התוסף: כניסה, כותרת, חיפוש תלמיד מהיר, ניווט, ומסכי הבית /
// תלמידים / כרטיס תלמיד / דיווחים / התראות. דרכון, הדפסות וחייגן — ב-views/.
// מוצג גם כחלון קטן מהכפתור וגם כטאב מלא (מהתפריט, או בלחיצה על התראה).
/* global INSTANCES, NOTIFY_ROLES, Api, UI, Passport, Prints, Dial */
var App = (function () {
  'use strict';
  var U = UI, $ = U.$, $$ = U.$$, esc = U.esc, icon = U.icon;

  var ATT = { present: 'נוכח', late: 'איחור', left: 'יצא באמצע', absent: 'חיסור' };
  var SEV = ['נמוכה', 'רגילה', 'גבוהה'];

  var S = {
    inst: null, cfg: null, prof: {},
    students: [], classes: [], cats: [], subjects: [], byClass: {},
    view: 'home', reports: null, reportsAt: 0,
    stuCls: '', stuInactive: false, stuQ: '',
    rep: { cls: '', cat: '', follow: false },
    cardId: null, cardPane: 'over',
  };

  var params = new URLSearchParams(location.search);
  // embed=1: בתוך החלונית הצפה (content/float.js) — ממלא את המסגרת. כל פרמטר אחר = טאב מלא.
  if (params.get('embed')) document.body.classList.add('embed');
  else if (Array.from(params.keys()).length) document.body.classList.add('tabmode');

  var has = function (f) { return !!(S.cfg && S.cfg.features && S.cfg.features[f]); };
  var canFeed = function () { return NOTIFY_ROLES.indexOf(S.prof.role) > -1; };
  var isActive = function (s) { return !s.status || s.status === 'פעיל'; };
  function activeStudents() { return S.students.filter(isActive); }
  function studentById(id) { return S.students.filter(function (s) { return String(s.id) === String(id); })[0] || null; }
  function className(id) { return S.byClass[id] || ''; }
  function catName(id) { var c = S.cats.filter(function (x) { return String(x.id) === String(id); })[0]; return c ? c.name : 'רישום'; }
  function sevCls(sev) { return sev === 'גבוהה' ? 'bad' : sev === 'נמוכה' ? 'ok' : 'neutral'; }

  var NAV = [
    { id: 'home', t: 'בית', ic: 'home' },
    { id: 'students', t: 'תלמידים', ic: 'users' },
    { id: 'reports', t: 'דיווחים', ic: 'report' },
    { id: 'passport', t: 'דרכון', ic: 'book', need: function () { return has('passport'); } },
    { id: 'prints', t: 'הדפסות', ic: 'printer', need: function () { return has('prints'); } },
    { id: 'dial', t: 'חייגן', ic: 'phone', need: function () { return has('dial') && S.prof.role === 'מנהל'; } },
  ];
  var VIEWS = {
    home: renderHome, students: renderStudents, reports: renderReports, feed: renderFeed,
    passport: function (h) { return Passport.render(h); },
    prints: function (h) { return Prints.render(h); },
    dial: function (h) { return Dial.render(h); },
  };
  function allowed(v) {
    if (v === 'feed') return canFeed();
    var n = NAV.filter(function (x) { return x.id === v; })[0];
    return !!n && (!n.need || n.need());
  }

  // ================= כניסה =================
  async function doLogin() {
    var msg = $('#lgMsg'); msg.className = 'form-msg'; msg.textContent = 'מתחבר…';
    var u = $('#lgUser').value.trim(), p = $('#lgPass').value;
    if (!u || !p) { msg.className = 'form-msg bad'; msg.textContent = 'נא להזין מספר טלפון וסיסמה.'; return; }
    $('#lgBtn').disabled = true;
    try {
      await Api.login(S.inst, u, p);
      await Api.save({ active: S.inst });
      msg.textContent = '';
      try { chrome.runtime.sendMessage({ type: 'poll' }); } catch (e) { /* בלי רקע */ }
      await showApp();
    } catch (e) { msg.className = 'form-msg bad'; msg.textContent = e.message || 'הכניסה נכשלה'; }
    finally { $('#lgBtn').disabled = false; }
  }

  // ================= מסגרת =================
  async function showApp() {
    $('#login').classList.add('hidden');
    $('#app').classList.remove('hidden');
    var sess = (await Api.sessions())[S.inst] || {};
    S.prof = { name: sess.name || '', role: sess.role || '', id: sess.user_id };
    $('#brandName').textContent = 'מעקב · ' + (S.cfg.short || S.cfg.name);
    $('#brandUser').textContent = (S.prof.name || '') + (S.prof.role ? ' · ' + S.prof.role : '');
    $('#bellBtn').classList.toggle('hidden', !canFeed());
    paintNav();
    await loadBase();
    var d = await Api.store(['lastView']);
    var want = params.get('tab') || d.lastView || 'home';
    go(allowed(want) ? want : 'home');
    updBell();
    if (params.get('student')) openCard(params.get('student'));
  }

  function paintNav() {
    var items = NAV.filter(function (n) { return !n.need || n.need(); });
    $('#nav').style.setProperty('--n', items.length);
    $('#nav').innerHTML = items.map(function (n) {
      return '<button class="nav-b" data-v="' + n.id + '">' + icon(n.ic) + '<span>' + esc(n.t) + '</span></button>';
    }).join('');
    $$('#nav .nav-b').forEach(function (b) { b.onclick = function () { go(b.dataset.v); }; });
  }

  async function loadBase() {
    try {
      var res = await Promise.all([
        Api.q.students(S.inst),
        Api.q.classes(S.inst).catch(function () { return []; }),
        Api.q.categories(S.inst).catch(function () { return []; }),
        Api.q.subjects(S.inst).catch(function () { return []; }),
      ]);
      S.students = res[0] || []; S.classes = res[1] || [];
      S.cats = (res[2] || []).filter(function (c) { return !c.kind || c.kind === 'behavior'; });
      S.subjects = res[3] || [];
      S.byClass = {}; S.classes.forEach(function (c) { S.byClass[c.id] = c.name; });
    } catch (e) { U.toast('טעינת הנתונים נכשלה: ' + e.message, true); }
  }

  function go(v) {
    if (!allowed(v)) v = 'home';
    S.view = v;
    $$('#nav .nav-b').forEach(function (b) { b.classList.toggle('on', b.dataset.v === v); });
    $('#bellBtn').classList.toggle('on', v === 'feed');
    hideResults();
    if (v !== 'students' && S.stuQ) { S.stuQ = ''; $('#q').value = ''; }
    $('#q').placeholder = v === 'students' ? 'סינון הרשימה לפי שם…' : 'חיפוש תלמיד מהיר…';
    var host = $('#view');
    host.scrollTop = 0;
    host.dataset.v = v;
    host.innerHTML = '';
    Api.save({ lastView: v === 'feed' ? 'home' : v });
    Promise.resolve(VIEWS[v](host)).catch(function (e) {
      host.innerHTML = U.empty('x', 'משהו השתבש', esc(e.message || e));
    });
  }
  function rerender() { if (VIEWS[S.view]) go(S.view); }

  // צ'יפים של כיתות (משותף לתלמידים ולדרכון). list = התלמידים שעליהם סופרים.
  function classChips(sel, list) {
    var cnt = {}; list.forEach(function (s) { cnt[s.class_id] = (cnt[s.class_id] || 0) + 1; });
    return '<button class="chip-btn' + (!sel ? ' on' : '') + '" data-c="">הכל <i>' + list.length + '</i></button>' +
      S.classes.filter(function (c) { return cnt[c.id]; }).map(function (c) {
        return '<button class="chip-btn' + (String(sel) === String(c.id) ? ' on' : '') + '" data-c="' + c.id + '">' + esc(c.name) + ' <i>' + cnt[c.id] + '</i></button>';
      }).join('');
  }
  function bindClassChips(box, onPick) {
    $$('.chip-btn', box).forEach(function (b) {
      b.onclick = function () {
        $$('.chip-btn', box).forEach(function (x) { x.classList.toggle('on', x === b); });
        onPick(b.dataset.c);
      };
    });
  }

  // ================= חיפוש מהיר =================
  var qHits = [], qIdx = 0;
  function hideResults() { $('#qRes').classList.add('hidden'); }
  function searchStudents(t) {
    t = t.trim(); if (!t) return [];
    var starts = [], inside = [];
    S.students.forEach(function (s) {
      var n = s.name || '', f = s.family || '';
      if (n.indexOf(t) === 0 || f.indexOf(t) === 0 || n.indexOf(' ' + t) > -1) starts.push(s);
      else if (n.indexOf(t) > -1 || f.indexOf(t) > -1) inside.push(s);
    });
    var act = function (a, b) { return (isActive(b) ? 1 : 0) - (isActive(a) ? 1 : 0); };
    return starts.sort(act).concat(inside.sort(act));
  }
  function onSearch() {
    var t = $('#q').value;
    if (S.view === 'students') { S.stuQ = t; paintStudentList(); hideResults(); return; }
    qHits = searchStudents(t).slice(0, 7); qIdx = 0;
    var box = $('#qRes');
    if (!t.trim()) { hideResults(); return; }
    box.classList.remove('hidden');
    box.innerHTML = qHits.length ? qHits.map(function (s, i) {
      return '<div class="q-o' + (i === 0 ? ' on' : '') + '" data-i="' + i + '">' + U.avatar(s.name, 'sm') +
        '<div class="grow"><b>' + esc(s.name) + '</b><span>' + esc(className(s.class_id) || 'ללא כיתה') + (isActive(s) ? '' : ' · ' + esc(s.status)) + '</span></div>' +
        '<button class="ic-btn sm" data-rep="' + i + '" title="דיווח מהיר">' + icon('edit') + '</button></div>';
    }).join('') + '<div class="q-foot">Enter = פתיחת כרטיס · ↑↓ בחירה · Esc סגירה</div>'
      : '<div class="q-none">לא נמצא תלמיד בשם הזה</div>';
    $$('.q-o', box).forEach(function (el) {
      el.onmousedown = function (e) {
        e.preventDefault();
        var s = qHits[+el.dataset.i];
        if (e.target.closest('[data-rep]')) { closeSearch(); behaviorSheet(s); return; }
        closeSearch(); openCard(s.id);
      };
    });
  }
  function closeSearch() { $('#q').value = ''; hideResults(); $('#q').blur(); }
  function onSearchKey(e) {
    if (e.key === 'Escape') { if ($('#q').value) { e.stopPropagation(); $('#q').value = ''; onSearch(); } $('#q').blur(); return; }
    if (S.view === 'students' || !qHits.length) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      qIdx = (qIdx + (e.key === 'ArrowDown' ? 1 : qHits.length - 1)) % qHits.length;
      $$('#qRes .q-o').forEach(function (b, i) { b.classList.toggle('on', i === qIdx); });
    } else if (e.key === 'Enter') { e.preventDefault(); var s = qHits[qIdx]; closeSearch(); openCard(s.id); }
  }

  // ================= מסך הבית =================
  function greet() {
    var h = new Date().getHours();
    return h >= 5 && h < 12 ? 'בוקר טוב' : h < 16 && h >= 12 ? 'צהריים טובים' : h >= 16 && h < 21 ? 'ערב טוב' : 'לילה טוב';
  }
  async function renderHome(host) {
    var act = activeStudents();
    var quick = [
      { id: 'rep', ic: 'edit', t: 'דיווח חדש' },
      has('passport') ? { id: 'psp', ic: 'book', t: 'דרכון' } : null,
      has('prints') ? { id: 'prn', ic: 'printer', t: 'דיווח הדפסה' } : null,
      { id: 'add', ic: 'userPlus', t: 'תלמיד חדש' },
    ].filter(Boolean);
    host.innerHTML =
      '<div class="hello"><h2>' + greet() + (S.prof.name ? ', ' + esc(S.prof.name) : '') + '</h2>' +
        '<p>' + esc(U.longToday()) + (U.hebDate() ? ' · ' + esc(U.hebDate()) : '') + '</p></div>' +
      '<div class="quick" style="--n:' + quick.length + '">' + quick.map(function (q) {
        return '<button class="quick-b" data-q="' + q.id + '">' + icon(q.ic) + '<span>' + esc(q.t) + '</span></button>';
      }).join('') + '</div>' +
      '<div id="hPrints"></div><div id="hPsp"></div><div id="hFeed"></div>' +
      '<div class="tile"><div class="tile-h">' + icon('report') + '<b>דיווחים אחרונים</b><button class="tile-more" id="hRepAll">לכל הדיווחים ' + icon('chevL') + '</button></div>' +
        '<div class="tile-b" id="hRep">' + U.loading() + '</div></div>' +
      '<div class="foot-stats">' + act.length + ' תלמידים פעילים · ' + S.classes.length + ' כיתות</div>';
    $$('.quick-b', host).forEach(function (b) {
      b.onclick = function () {
        var q = b.dataset.q;
        if (q === 'rep') behaviorSheet(null);
        if (q === 'psp') go('passport');
        if (q === 'prn') Prints.quickJob(function () { if (S.view === 'home') Prints.homeCard($('#hPrints')); });
        if (q === 'add') addStudentSheet();
      };
    });
    $('#hRepAll', host).onclick = function () { go('reports'); };
    if (has('prints')) Prints.homeCard($('#hPrints', host));
    if (has('passport')) Passport.homeCard($('#hPsp', host));
    if (canFeed()) homeFeed($('#hFeed', host));
    try {
      var rows = await getReports();
      var box = $('#hRep', host); if (!box) return;
      box.innerHTML = rows.length ? rows.slice(0, 4).map(repRow).join('') : '<div class="meta">אין דיווחים עדיין.</div>';
      bindRepRows(box);
    } catch (e) { var b = $('#hRep', host); if (b) b.innerHTML = '<div class="meta bad">' + esc(e.message) + '</div>'; }
  }

  async function homeFeed(host) {
    var st = await feedState();
    var items = (st.items || []).slice(0, 3);
    var un = st.unread || 0;
    host.innerHTML = '<div class="tile clickable" id="hfT"><div class="tile-h">' + icon('bell') + '<b>התראות</b>' +
      (un ? '<span class="chip bad">' + un + ' חדשות</span>' : '') + '<span class="tile-more">לכולן ' + icon('chevL') + '</span></div>' +
      '<div class="tile-b">' + (items.length ? items.map(function (it) {
        return '<div class="mini-row"><div class="grow"><b>' + esc(it.title || 'רישום') + (it.student_name ? ' · ' + esc(it.student_name) : '') + '</b>' +
          '<div class="meta">' + esc(it.actor_name || '') + ' · ' + esc(U.fmtWhen(it.created_at)) + '</div></div></div>';
      }).join('') : '<div class="meta">' + (st.error ? 'שגיאה: ' + esc(st.error) : 'אין תנועה חדשה.') + '</div>') + '</div></div>';
    $('#hfT', host).onclick = function () { go('feed'); };
  }

  // ================= תלמידים =================
  function renderStudents(host) {
    var base = S.students.filter(function (s) { return S.stuInactive || isActive(s); });
    host.innerHTML =
      '<div class="chips scroll" id="stCls">' + classChips(S.stuCls, base) + '</div>' +
      '<div class="list-h"><span id="stCount"></span>' +
        '<label class="switch"><input type="checkbox" id="stInact"' + (S.stuInactive ? ' checked' : '') + '><span>כולל לא פעילים</span></label>' +
        '<button class="btn sm primary" id="stAdd">' + icon('userPlus') + '<span>תלמיד חדש</span></button></div>' +
      '<div id="stList" class="list"></div>';
    bindClassChips($('#stCls', host), function (v) { S.stuCls = v; paintStudentList(); });
    $('#stInact', host).onchange = function () { S.stuInactive = this.checked; renderStudents(host); };
    $('#stAdd', host).onclick = function () { addStudentSheet(); };
    if (S.stuQ) $('#q').value = S.stuQ;
    paintStudentList();
  }
  function paintStudentList() {
    var box = $('#stList'); if (!box) return;
    var t = (S.stuQ || '').trim();
    var list = (t ? searchStudents(t) : S.students).filter(function (s) {
      if (!S.stuInactive && !isActive(s)) return false;
      if (S.stuCls && String(s.class_id) !== S.stuCls) return false;
      return true;
    });
    $('#stCount').textContent = list.length + ' תלמידים';
    if (!list.length) { box.innerHTML = U.empty('search', 'לא נמצא תלמיד מתאים', t ? 'אפשר לנקות את החיפוש למעלה.' : ''); return; }
    box.innerHTML = list.map(function (s) {
      return '<div class="row' + (isActive(s) ? '' : ' dim') + '" data-id="' + s.id + '">' + U.avatar(s.name) +
        '<div class="grow"><b>' + esc(s.name) + '</b><div class="meta">' + esc(className(s.class_id) || 'ללא כיתה') +
        (isActive(s) ? '' : ' · <span class="chip mute">' + esc(s.status) + '</span>') + '</div></div>' +
        '<button class="ic-btn sm" data-rep="' + s.id + '" title="דיווח מהיר">' + icon('edit') + '</button>' +
        '<span class="chev">' + icon('chevL') + '</span></div>';
    }).join('');
    $$('.row', box).forEach(function (r) {
      r.onclick = function (e) {
        if (e.target.closest('[data-rep]')) { behaviorSheet(studentById(r.dataset.id)); return; }
        openCard(r.dataset.id);
      };
    });
  }

  function addStudentSheet() {
    var cls = U.options(S.classes.map(function (c) { return { v: c.id, t: c.name }; }), '', '— בחירה —');
    U.sheet({
      title: 'תלמיד חדש', wide: true,
      body: '<div class="form">' +
        U.field('adName', 'שם מלא (כולל משפחה)', 'text', { full: true, req: true, autofocus: true }) +
        U.field('adFamily', 'שם משפחה', 'text', { hint: 'מתמלא לבד' }) +
        U.field('adClass', 'כיתה / שיעור', 'select', { options: cls }) +
        U.field('adTz', 'תעודת זהות', 'text', { inputmode: 'numeric', dir: 'ltr' }) +
        U.field('adStatus', 'סטטוס', 'select', { options: U.options(['פעיל', 'לא פעיל'], 'פעיל') }) +
        U.field('adBd', 'תאריך לידה', 'date') +
        U.field('adBdh', 'תאריך לידה עברי', 'text') +
        '<div class="form-sep full">הורים</div>' +
        U.field('adFname', 'שם האב', 'text') + U.field('adFphone', 'נייד האב', 'tel', { dir: 'ltr' }) +
        U.field('adMname', 'שם האם', 'text') + U.field('adMphone', 'נייד האם', 'tel', { dir: 'ltr' }) +
        U.field('adMemail', 'אימייל האם', 'email', { full: true, dir: 'ltr' }) +
        U.field('adAddr', 'כתובת', 'text', { full: true }) +
        U.field('adNotes', 'הערות', 'textarea', { full: true, rows: 2 }) + '</div>',
      saveLabel: 'שמירת התלמיד',
      onOpen: function (el) {
        $('#adName', el).addEventListener('blur', function () {
          // השלמה: אם לא הוקלד שם משפחה — המילה האחרונה מהשם המלא.
          var f = $('#adFamily', el);
          if (!f.value.trim()) { var p = this.value.trim().split(/\s+/); if (p.length > 1) f.value = p[p.length - 1]; }
        });
      },
      onSave: async function (el, api) {
        var v = function (id) { return $('#' + id, el).value.trim() || null; };
        var row = {
          name: $('#adName', el).value.trim(), family: v('adFamily'), tz: v('adTz'),
          class_id: $('#adClass', el).value ? Number($('#adClass', el).value) : null,
          status: $('#adStatus', el).value, birthdate: v('adBd'), birthdate_heb: v('adBdh'),
          parent_name: v('adFname'), parent_phone: v('adFphone'), mother_name: v('adMname'),
          mother_phone: v('adMphone'), mother_email: v('adMemail'), address: v('adAddr'), notes: v('adNotes'),
        };
        if (!row.name) { api.msg('חובה להזין שם'); return false; }
        // כפילות שקטה היא הבעיה הכי מעצבנת בהוספה מהירה — עוצרים מראש.
        if (S.students.some(function (s) { return s.name === row.name; })) { api.msg('כבר קיים תלמיד בשם הזה — לבדוק ברשימה.'); return false; }
        var r = await Api.q.addStudent(S.inst, row);
        U.toast('התלמיד ' + row.name + ' נוסף');
        await loadBase();
        if (S.view === 'students' || S.view === 'home') rerender();
        if (r && r[0]) openCard(r[0].id);
        return true;
      },
    });
  }

  // ================= טפסי הזנה מהירה =================
  // דיווח מעקב. stu=null → בוחרים תלמיד בתוך הטופס.
  function behaviorSheet(stu, onDone) {
    var picker = null;
    U.sheet({
      title: 'דיווח מעקב', sub: stu ? esc(stu.name) + (className(stu.class_id) ? ' · ' + esc(className(stu.class_id)) : '') : '',
      body: '<div class="form">' + (stu ? '' : '<div class="fld full"><span class="lbl">תלמיד <i class="req">*</i></span><div id="bsPick"></div></div>') +
        '<div class="fld full"><span class="lbl">קטגוריה <i class="req">*</i></span>' +
          (S.cats.length ? U.seg('bsCat', S.cats.map(function (c) { return { v: c.id, t: c.name }; }), '', { wrap: true }) : '<div class="meta bad">לא הוגדרו קטגוריות במערכת</div>') + '</div>' +
        '<div class="fld full"><span class="lbl">חומרה</span>' + U.seg('bsSev', SEV.map(function (x) { return { v: x, t: x, cls: sevCls(x) }; }), 'רגילה') + '</div>' +
        '<div class="fld full"><span class="lbl">תאריך</span><div class="date-row"><input id="bsDate" class="inp" type="date" value="' + U.today() + '">' +
          U.seg('bsDq', [{ v: '0', t: 'היום' }, { v: '1', t: 'אתמול' }], '0', { cls: 'mini' }) + '</div></div>' +
        U.field('bsNote', 'תיאור', 'textarea', { full: true, rows: 3, ph: 'מה קרה? (לא חובה)' }) +
        '<label class="check full"><input type="checkbox" id="bsFollow"><span>לסמן למעקב — לחזור לזה בהמשך</span></label>' +
        '</div><div class="hint">Ctrl+Enter = שמירה</div>',
      saveLabel: 'שמירת הדיווח',
      onOpen: function (el) {
        if (!stu) picker = U.studentPicker($('#bsPick', el), S.students.filter(isActive), S.byClass, function () {
          var f = $('#bsCat .seg-o', el); if (f) f.focus();
        });
        U.bindSeg(el, function (id, v) {
          if (id === 'bsDq' && v !== '') {
            var d = new Date(); d.setDate(d.getDate() - Number(v));
            $('#bsDate', el).value = d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
          }
        });
      },
      onSave: async function (el, api) {
        var sid = stu ? stu.id : picker && picker.value();
        var cat = U.segVal(el, 'bsCat');
        if (!sid) { api.msg('נא לבחור תלמיד'); return false; }
        if (!cat) { api.msg('נא לבחור קטגוריה'); return false; }
        await Api.q.addBehavior(S.inst, {
          student_id: Number(sid), category_id: Number(cat), severity: U.segVal(el, 'bsSev') || 'רגילה',
          event_date: $('#bsDate', el).value || U.today(), note: $('#bsNote', el).value.trim() || null,
          followup: $('#bsFollow', el).checked, created_by: S.prof.id,
        });
        U.toast('הדיווח נשמר');
        S.reports = null;
        if (onDone) onDone(); else if (S.view === 'reports' || S.view === 'home') rerender();
        return true;
      },
    });
  }

  function attendanceSheet(stu, onDone) {
    U.sheet({
      title: 'נוכחות', sub: esc(stu.name),
      body: '<div class="form"><div class="fld full"><span class="lbl">סימון</span>' +
        U.seg('atSt', [{ v: 'present', t: 'נוכח', cls: 'ok' }, { v: 'late', t: 'איחור', cls: 'neutral' }, { v: 'left', t: 'יצא באמצע', cls: 'neutral' }, { v: 'absent', t: 'חיסור', cls: 'bad' }], 'present', { cls: 'big' }) + '</div>' +
        U.field('atDate', 'תאריך', 'date', { value: U.today() }) +
        U.field('atNote', 'הערה', 'text', { ph: 'לא חובה' }) + '</div>' +
        '<div class="hint">יום שכבר סומן — מתעדכן (שורה אחת לתלמיד ליום, כמו באתר).</div>',
      onOpen: function (el) { U.bindSeg(el); },
      onSave: async function (el) {
        await Api.q.addAttendance(S.inst, {
          student_id: stu.id, date: $('#atDate', el).value || U.today(), status: U.segVal(el, 'atSt'),
          note: $('#atNote', el).value.trim() || null, created_by: S.prof.id,
        });
        U.toast('הנוכחות נשמרה'); if (onDone) onDone(); return true;
      },
    });
  }

  function testSheet(stu, onDone) {
    U.sheet({
      title: 'מבחן', sub: esc(stu.name),
      body: '<div class="form">' +
        '<label class="fld full"><span class="lbl">מקצוע</span><input id="tsSubj" class="inp" list="tsSubjects" autofocus>' +
          '<datalist id="tsSubjects">' + S.subjects.map(function (s) { return '<option value="' + esc(s.name) + '">'; }).join('') + '</datalist></label>' +
        U.field('tsGrade', 'ציון', 'number', { min: 0, max: 100, inputmode: 'numeric' }) +
        U.field('tsDate', 'תאריך', 'date', { value: U.today() }) +
        U.field('tsNote', 'הערה', 'text', { full: true, ph: 'לא חובה' }) + '</div>',
      onSave: async function (el, api) {
        var g = $('#tsGrade', el).value;
        if (g !== '' && !(Number(g) >= 0)) { api.msg('ציון לא תקין'); return false; }
        await Api.q.addTest(S.inst, {
          student_id: stu.id, subject: $('#tsSubj', el).value.trim() || null, grade: g === '' ? null : Number(g),
          test_date: $('#tsDate', el).value || U.today(), note: $('#tsNote', el).value.trim() || null, created_by: S.prof.id,
        });
        U.toast('המבחן נשמר'); if (onDone) onDone(); return true;
      },
    });
  }

  // ================= כרטיס תלמיד =================
  async function openCard(id, pane) {
    S.cardId = id; S.cardPane = pane || 'over';
    hideResults(); $('#menu').classList.add('hidden');
    var layer = $('#card');
    layer.classList.remove('hidden');
    var pre = studentById(id);
    $('#cardHead').innerHTML = pre ? cardHead(pre) : '<b>טוען…</b>';
    $('#cardBody').innerHTML = U.loading('טוען את הכרטיס…');
    var st;
    try { st = await Api.q.student(S.inst, id); }
    catch (e) { $('#cardBody').innerHTML = U.empty('x', 'טעינת הכרטיס נכשלה', esc(e.message)); return; }
    if (S.cardId !== id) return;
    if (!st) { $('#cardBody').innerHTML = U.empty('lock', 'התלמיד לא נמצא', 'ייתכן שאין לך הרשאה אליו.'); return; }
    $('#cardHead').innerHTML = cardHead(st);
    var parts = await Promise.all([
      Api.q.behavior(S.inst, id).catch(function () { return []; }),
      Api.q.attendance(S.inst, id).catch(function () { return []; }),
      Api.q.tests(S.inst, id).catch(function () { return []; }),
      Api.q.reading(S.inst, id).catch(function () { return []; }),
      canFeed() ? Api.q.studentFeed(S.inst, id).catch(function () { return []; }) : Promise.resolve(null),
      has('passport') ? Api.q.passportByStudent(S.inst, id).catch(function () { return []; }) : Promise.resolve(null),
    ]);
    if (S.cardId !== id) return;
    renderCard(st, { beh: parts[0] || [], att: parts[1] || [], tests: parts[2] || [], reading: parts[3] || [], feed: parts[4], psp: parts[5] });
  }
  function closeCard() { $('#card').classList.add('hidden'); S.cardId = null; }
  function cardHead(st) {
    return U.avatar(st.name, 'md') + '<div><b>' + esc(st.name) + '</b><small>' + esc(className(st.class_id) || 'ללא כיתה') +
      (st.status && st.status !== 'פעיל' ? ' · ' + esc(st.status) : '') + '</small></div>';
  }

  function attStats(att) {
    var cnt = function (keys) { return att.filter(function (a) { return keys.indexOf(a.status) > -1; }).length; };
    var present = cnt(['present', 'נוכח', 'late', 'איחור', 'left', 'יצא']);
    var absent = cnt(['absent', 'חיסור', 'נעדר']);
    return { pct: att.length ? Math.round(present / att.length * 100) : null, absent: absent };
  }
  function attCls(s) { return (s === 'absent' || s === 'חיסור' || s === 'נעדר') ? 'bad' : (s === 'present' || s === 'נוכח') ? 'ok' : 'neutral'; }

  function renderCard(st, d) {
    var a = attStats(d.att);
    var grades = d.tests.filter(function (t) { return t.grade != null; }).map(function (t) { return Number(t.grade); });
    var avg = grades.length ? Math.round(grades.reduce(function (x, y) { return x + y; }, 0) / grades.length) : null;
    var follow = d.beh.filter(function (e) { return e.followup; }).length;
    var pspLast = d.psp ? Passport.lastScore(d.psp) : null;
    var reload = function () { openCard(st.id, S.cardPane); };

    var kpis = [
      { v: a.pct == null ? '—' : a.pct + '%', t: 'הגעה', s: d.att.length ? d.att.length + ' ימים' : 'אין רישום', cls: a.pct != null && a.pct < 85 ? 'warn' : '' },
      { v: avg == null ? '—' : avg, t: 'ממוצע מבחנים', s: grades.length ? grades.length + ' מבחנים' : 'אין מבחנים' },
      { v: d.beh.length, t: 'דיווחי מעקב', s: follow ? follow + ' במעקב' : 'אין פתוחים', cls: follow ? 'warn' : '' },
    ];
    if (d.psp) kpis.push({ v: pspLast == null ? '—' : pspLast, t: 'דרכון', s: d.psp.length ? 'שבוע ' + Math.max.apply(null, d.psp.map(function (r) { return r.week_no; })) : 'ריק' });
    var acts = [
      { id: 'beh', ic: 'edit', t: 'דיווח' }, { id: 'att', ic: 'att', t: 'נוכחות' }, { id: 'test', ic: 'star', t: 'מבחן' },
    ];
    if (d.psp) acts.push({ id: 'psp', ic: 'book', t: 'דרכון' });
    var panes = [{ v: 'over', t: 'סקירה' }, { v: 'beh', t: 'מעקב' }, { v: 'att', t: 'נוכחות' }, { v: 'tests', t: 'מבחנים' }];
    if (d.psp) panes.push({ v: 'psp', t: 'דרכון' });
    panes.push({ v: 'info', t: 'פרטים' });

    $('#cardBody').innerHTML =
      '<div class="kpis" style="--n:' + kpis.length + '">' + kpis.map(function (k) {
        return '<div class="kpi ' + (k.cls || '') + '"><b>' + esc(k.v) + '</b><span>' + esc(k.t) + '</span><small>' + esc(k.s) + '</small></div>';
      }).join('') + '</div>' +
      '<div class="quick card-q" style="--n:' + acts.length + '">' + acts.map(function (x) {
        return '<button class="quick-b sm" data-a="' + x.id + '">' + icon('plus') + '<span>' + esc(x.t) + '</span></button>';
      }).join('') + '</div>' +
      U.seg('cardTabs', panes, S.cardPane, { cls: 'tabs-seg' }) +
      '<div id="cardPane" class="pane"></div>';

    $$('#cardBody [data-a]').forEach(function (b) {
      b.onclick = function () {
        var k = b.dataset.a;
        if (k === 'beh') behaviorSheet(st, reload);
        if (k === 'att') attendanceSheet(st, reload);
        if (k === 'test') testSheet(st, reload);
        if (k === 'psp') Passport.quickSheet(st, d.psp, reload);
      };
    });
    U.bindSeg($('#cardBody'), function (id, v) { if (id === 'cardTabs') setPane(v); });

    function behList(rows) {
      return rows.length ? rows.map(function (e) {
        return '<div class="mini-row"><span class="chip ' + sevCls(e.severity) + '">' + esc(catName(e.category_id)) + '</span>' +
          '<div class="grow">' + (e.note ? esc(e.note) : '<span class="meta">בלי תיאור</span>') +
          '<div class="meta">' + esc(U.dayLabel(e.event_date)) + (e.followup ? ' · <span class="flag">' + icon('flag') + 'במעקב</span>' : '') + '</div></div></div>';
      }).join('') : U.empty('report', 'אין דיווחי מעקב');
    }
    function attStrip() {
      var last = d.att.slice(0, 20).reverse();
      return last.length ? '<div class="strip" title="20 הימים האחרונים שנרשמו">' + last.map(function (x) {
        return '<i class="' + attCls(x.status) + '" title="' + esc(U.fmtDate(x.date) + ' — ' + (ATT[x.status] || x.status)) + '"></i>';
      }).join('') + '</div>' : '';
    }
    function phoneRow(label, name, phone) {
      if (!phone && !name) return '';
      return '<div class="contact">' + icon('user') + '<div class="grow"><b>' + esc(name || '—') + '</b><span>' + esc(label) + '</span></div>' +
        (phone ? '<span class="ph" dir="ltr">' + esc(phone) + '</span><button class="ic-btn sm" data-copy="' + esc(phone) + '" title="העתקה">' + icon('copy') + '</button>' +
          (has('dial') && S.prof.role === 'מנהל' ? '<button class="ic-btn sm" data-dial="' + esc(phone) + '" data-n="' + esc(name || label) + '" title="חיוג דרך המרכזייה">' + icon('phone') + '</button>' : '') : '') +
        '</div>';
    }

    function setPane(p) {
      S.cardPane = p;
      var g = $('#cardTabs'); if (g) { g.dataset.val = p; $$('.seg-o', g).forEach(function (b) { b.classList.toggle('on', b.dataset.v === p); }); }
      var box = $('#cardPane'); if (!box) return;
      var h = '';
      if (p === 'over') {
        h += '<div class="contacts">' + phoneRow('אבא', st.parent_name, st.parent_phone) + phoneRow('אמא', st.mother_name, st.mother_phone) + '</div>';
        if (d.att.length) h += '<h4 class="sec-h">' + icon('att') + 'נוכחות אחרונה</h4>' + attStrip();
        h += '<h4 class="sec-h">' + icon('report') + 'דיווחים אחרונים</h4>' + behList(d.beh.slice(0, 3));
        if (d.feed && d.feed.length) {
          h += '<h4 class="sec-h">' + icon('clock') + 'מי עדכן לאחרונה</h4>' + d.feed.slice(0, 4).map(function (f) {
            return '<div class="mini-row"><div class="grow">' + esc(f.actor_name || '') + ' — ' + esc(f.title || '') +
              '<div class="meta">' + esc(U.fmtWhen(f.created_at)) + (f.detail ? ' · ' + esc(f.detail) : '') + '</div></div></div>';
          }).join('');
        }
      } else if (p === 'beh') h = behList(d.beh);
      else if (p === 'att') {
        h = d.att.length ? '<div class="sum-line">' + a.pct + '% הגעה · ' + a.absent + ' חיסורים · ' + d.att.length + ' ימים רשומים</div>' + attStrip() +
          d.att.map(function (x) {
            return '<div class="mini-row"><span class="chip ' + attCls(x.status) + '">' + esc(ATT[x.status] || x.status || '') + '</span>' +
              '<div class="grow">' + esc(U.dayLabel(x.date)) + (x.note ? ' — ' + esc(x.note) : '') + '</div></div>';
          }).join('') : U.empty('att', 'אין רישומי נוכחות');
      } else if (p === 'tests') {
        h = d.tests.length ? d.tests.map(function (t) {
          return '<div class="mini-row"><span class="grade' + (t.grade != null && t.grade < 60 ? ' bad' : '') + '">' + esc(t.grade == null ? '—' : t.grade) + '</span>' +
            '<div class="grow"><b>' + esc(t.subject || 'מבחן') + '</b><div class="meta">' + esc(U.fmtDate(t.test_date)) + (t.note ? ' · ' + esc(t.note) : '') + '</div></div></div>';
        }).join('') : U.empty('star', 'אין מבחנים');
        if (d.reading.length) h += '<h4 class="sec-h">' + icon('book') + 'מעקב קריאה</h4>' + d.reading.map(function (r) {
          return '<div class="mini-row"><div class="grow">' + esc(r.level || '') + '<div class="meta">' + esc(U.fmtDate(r.date)) + (r.note ? ' · ' + esc(r.note) : '') + '</div></div></div>';
        }).join('');
      } else if (p === 'psp') h = Passport.cardPane(d.psp);
      else if (p === 'info') {
        var kv = function (k, v) { return v ? '<dt>' + esc(k) + '</dt><dd>' + esc(v) + '</dd>' : ''; };
        h = '<dl class="kv">' + kv('שם מלא', st.name) + kv('משפחה', st.family) + kv('כיתה', className(st.class_id)) +
          kv('סטטוס', st.status) + kv('ת״ז', st.tz) + kv('תאריך לידה', st.birthdate ? U.fmtDate(st.birthdate) : '') +
          kv('לידה עברי', st.birthdate_heb) + kv('אב', st.parent_name) + kv('נייד אב', st.parent_phone) +
          kv('אם', st.mother_name) + kv('נייד אם', st.mother_phone) + kv('אימייל אם', st.mother_email) +
          kv('כתובת', st.address) + kv('הערות', st.notes) + '</dl>' +
          '<button class="link-btn" id="cardSite2">' + icon('external') + 'עריכת הפרטים — באתר המלא</button>';
      }
      box.innerHTML = h;
      $$('[data-copy]', box).forEach(function (b) { b.onclick = function () { U.copy(b.dataset.copy); }; });
      $$('[data-dial]', box).forEach(function (b) { b.onclick = function () { Dial.dialNumber(b.dataset.dial, b.dataset.n + ' (' + st.name + ')', st.id); }; });
      var s2 = $('#cardSite2', box); if (s2) s2.onclick = function () { U.openUrl(S.cfg.site); };
    }
    setPane(S.cardPane);
  }

  // ================= דיווחים =================
  async function getReports(force) {
    if (!force && S.reports && Date.now() - S.reportsAt < 60000) return S.reports;
    S.reports = await Api.q.behaviorAll(S.inst, 120) || [];
    S.reportsAt = Date.now();
    return S.reports;
  }
  function repRow(r) {
    var s = studentById(r.student_id);
    var name = s ? s.name : 'תלמיד לא ידוע';
    return '<div class="row rep-row" data-sid="' + r.student_id + '">' + U.avatar(name, 'sm') +
      '<div class="grow"><div class="rep-t"><b>' + esc(name) + '</b><span class="chip ' + sevCls(r.severity) + '">' + esc(catName(r.category_id)) + '</span>' +
        (r.followup ? '<span class="flag">' + icon('flag') + 'במעקב</span>' : '') + '</div>' +
        (r.note ? '<div class="rep-n">' + esc(r.note) + '</div>' : '') +
        '<div class="meta">' + esc(U.dayLabel(r.event_date)) + (s && className(s.class_id) ? ' · ' + esc(className(s.class_id)) : '') + '</div></div></div>';
  }
  function bindRepRows(box) { $$('.rep-row', box).forEach(function (r) { r.onclick = function () { openCard(r.dataset.sid); }; }); }

  async function renderReports(host) {
    host.innerHTML =
      '<div class="toolbar">' +
        '<select id="rpCls" class="inp mini">' + U.options(S.classes.map(function (c) { return { v: c.id, t: c.name }; }), S.rep.cls, 'כל הכיתות') + '</select>' +
        '<select id="rpCat" class="inp mini">' + U.options(S.cats.map(function (c) { return { v: c.id, t: c.name }; }), S.rep.cat, 'כל הקטגוריות') + '</select>' +
        '<button class="btn sm primary" id="rpNew">' + icon('plus') + '<span>דיווח</span></button></div>' +
      '<div class="list-h"><span id="rpCount"></span><label class="switch"><input type="checkbox" id="rpFollow"' + (S.rep.follow ? ' checked' : '') + '><span>רק במעקב</span></label></div>' +
      '<div id="rpList" class="list">' + U.loading() + '</div>';
    $('#rpCls', host).onchange = function () { S.rep.cls = this.value; paint(); };
    $('#rpCat', host).onchange = function () { S.rep.cat = this.value; paint(); };
    $('#rpFollow', host).onchange = function () { S.rep.follow = this.checked; paint(); };
    $('#rpNew', host).onclick = function () { behaviorSheet(null); };
    var rows;
    try { rows = await getReports(true); }
    catch (e) { $('#rpList', host).innerHTML = U.empty('x', 'טעינת הדיווחים נכשלה', esc(e.message)); return; }
    function paint() {
      var inCls = null;
      if (S.rep.cls) { inCls = {}; S.students.forEach(function (s) { if (String(s.class_id) === S.rep.cls) inCls[s.id] = true; }); }
      var list = rows.filter(function (r) {
        if (inCls && !inCls[r.student_id]) return false;
        if (S.rep.cat && String(r.category_id) !== S.rep.cat) return false;
        if (S.rep.follow && !r.followup) return false;
        return true;
      });
      $('#rpCount', host).textContent = list.length + ' דיווחים' + (rows.length >= 120 ? ' (מתוך 120 האחרונים)' : '');
      var box = $('#rpList', host);
      if (!list.length) { box.innerHTML = U.empty('report', 'אין דיווחים תואמים', 'אפשר לשנות את הסינון, או להוסיף דיווח חדש.'); return; }
      var h = '', last = '';
      list.forEach(function (r) {
        var day = U.dayLabel(r.event_date);
        if (day !== last) { h += '<div class="daysep">' + esc(day) + '</div>'; last = day; }
        h += repRow(r);
      });
      box.innerHTML = h;
      bindRepRows(box);
    }
    paint();
  }

  // ================= התראות =================
  async function feedState() {
    var d = await Api.store(['feedState']);
    return (d.feedState || {})[S.inst] || {};
  }
  async function updBell() {
    if (!canFeed()) return;
    var st = await feedState();
    var n = st.unread || 0, b = $('#bellBadge');
    b.textContent = n > 99 ? '99+' : n; b.classList.toggle('hidden', !n);
  }
  async function renderFeed(host) {
    var st = await feedState();
    var items = st.items || [], unread = st.unread || 0;
    host.innerHTML = '<div class="view-h"><div><h3>התראות</h3><small>' +
      esc(st.error ? 'שגיאה: ' + st.error : st.checkedAt ? 'נבדק ' + U.fmtWhen(st.checkedAt) : 'טרם נבדק') + ' · נבדק כל דקה</small></div>' +
      '<button class="btn sm" id="fdPoll">' + icon('refresh') + '<span>בדיקה עכשיו</span></button></div>' +
      '<div id="fdList" class="list"></div>';
    var box = $('#fdList', host);
    if (!items.length) box.innerHTML = U.empty('bell', 'אין עדיין רישומים חדשים', 'ברגע שאיש צוות יזין נתון — תקפוץ כאן התראה.');
    else {
      var h = '', last = '';
      items.forEach(function (it, i) {
        var day = U.dayLabel(it.created_at);
        if (day !== last) { h += '<div class="daysep">' + esc(day) + '</div>'; last = day; }
        h += '<div class="row' + (i < unread ? ' unread' : '') + '" data-sid="' + (it.student_id || '') + '">' +
          '<span class="tl-ic">' + icon(it.kind === 'attendance' ? 'att' : it.kind === 'test' ? 'star' : it.kind === 'student' ? 'user' : 'edit') + '</span>' +
          '<div class="grow"><b>' + esc(it.title || 'רישום') + (it.student_name ? ' · ' + esc(it.student_name) : '') + '</b>' +
          '<div class="meta">' + esc(it.actor_name || '') + (it.actor_role ? ' (' + esc(it.actor_role) + ')' : '') + ' · ' + esc(U.fmtTime(it.created_at)) +
          (it.detail ? '<br>' + esc(it.detail) : '') + '</div></div></div>';
      });
      box.innerHTML = h;
      $$('.row', box).forEach(function (r) { r.onclick = function () { if (r.dataset.sid) openCard(r.dataset.sid); }; });
    }
    $('#fdPoll', host).onclick = function () {
      this.disabled = true;
      msg({ type: 'poll' }, function () { if (S.view === 'feed') renderFeed(host); updBell(); });
    };
    // מי שפתח את המסך ראה — מסמנים כנקרא (ההדגשה נשארת עד הרענון הבא).
    if (unread) msg({ type: 'markRead', inst: S.inst }, updBell);
  }
  function msg(m, cb) {
    try { chrome.runtime.sendMessage(m, function (r) { void chrome.runtime.lastError; if (cb) cb(r); }); }
    catch (e) { if (cb) cb(null); }
  }

  // ================= תפריט =================
  async function toggleMenu() {
    var m = $('#menu');
    if (!m.classList.contains('hidden')) { m.classList.add('hidden'); return; }
    var p = (await Api.store(['prefs'])).prefs || {};
    var notifyOn = p.notify !== false;
    var tab = document.body.classList.contains('tabmode');
    m.innerHTML = '<div class="menu-who">' + U.avatar(S.prof.name || '?', 'md') + '<div><b>' + esc(S.prof.name || '—') + '</b><small>' + esc(S.prof.role || '') + ' · ' + esc(S.cfg.name) + '</small></div></div>' +
      '<button data-m="refresh">' + icon('refresh') + 'רענון הנתונים</button>' +
      (tab ? '' : '<button data-m="full">' + icon('expand') + 'פתיחה בחלון גדול</button>') +
      '<button data-m="site">' + icon('external') + 'פתיחת האתר המלא</button>' +
      '<button data-m="float">' + icon('inbox') + 'בועה צפה באתרים: <b>' + (p.gmailFloat === false ? 'מוסתרת' : 'מוצגת') + '</b></button>' +
      (canFeed() ? '<button data-m="notify">' + icon('bell') + 'התראות קופצות: <b>' + (notifyOn ? 'פועלות' : 'כבויות') + '</b></button>' : '') +
      '<button data-m="out" class="danger">' + icon('logout') + 'יציאה</button>' +
      '<div class="menu-ver">גרסה ' + esc((chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '')) + '</div>';
    m.classList.remove('hidden');
    $$('[data-m]', m).forEach(function (b) {
      b.onclick = async function () {
        m.classList.add('hidden');
        var k = b.dataset.m;
        if (k === 'refresh') refresh();
        if (k === 'full') U.openUrl(chrome.runtime.getURL('popup.html?full=1'));
        if (k === 'site') U.openUrl(S.cfg.site);
        if (k === 'float') { p.gmailFloat = p.gmailFloat === false; await Api.save({ prefs: p }); U.toast(p.gmailFloat ? 'הבועה תוצג בכל האתרים (אחרי רענון הדף)' : 'הבועה הוסתרה'); }
        if (k === 'notify') { p.notify = !notifyOn; await Api.save({ prefs: p }); U.toast(p.notify ? 'ההתראות הקופצות הופעלו' : 'ההתראות הקופצות כובו'); }
        if (k === 'out') { if (await U.confirm('לצאת מהחשבון?', 'יציאה')) { await Api.logout(S.inst); location.reload(); } }
      };
    });
  }
  async function refresh() {
    S.reports = null;
    await loadBase();
    msg({ type: 'poll' }, updBell);
    rerender();
    if (S.cardId) openCard(S.cardId, S.cardPane);
    U.toast('הנתונים רועננו');
  }

  // ================= אתחול =================
  async function boot() {
    var keys = Object.keys(INSTANCES);
    S.inst = params.get('inst') && INSTANCES[params.get('inst')] ? params.get('inst') : keys[0];
    S.cfg = INSTANCES[S.inst];
    document.documentElement.style.setProperty('--acc', S.cfg.color);
    document.title = 'מעקב · ' + (S.cfg.short || S.cfg.name);
    $('#lgInst').textContent = S.cfg.name;
    $('#bellIc').innerHTML = icon('bell');
    $('#menuIc').innerHTML = icon('more');
    $('#qIc').innerHTML = icon('search');
    $('#cardBack').innerHTML = icon('chevR');
    $('#cardSite').innerHTML = icon('external');
    var sess = await Api.sessions();
    if (sess[S.inst]) await showApp();
    else { $('#login').classList.remove('hidden'); $('#lgUser').focus(); }
  }

  $('#lgBtn').onclick = doLogin;
  $('#lgPass').addEventListener('keydown', function (e) { if (e.key === 'Enter') doLogin(); });
  $('#lgUser').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('#lgPass').focus(); });
  $('#q').addEventListener('input', onSearch);
  $('#q').addEventListener('keydown', onSearchKey);
  $('#q').addEventListener('focus', function () { if (S.view !== 'students' && this.value.trim()) onSearch(); });
  $('#q').addEventListener('blur', function () { setTimeout(hideResults, 150); });
  $('#bellBtn').onclick = function () { go(S.view === 'feed' ? 'home' : 'feed'); };
  $('#menuBtn').onclick = function (e) { e.stopPropagation(); toggleMenu(); };
  $('#cardBack').onclick = closeCard;
  $('#cardSite').onclick = function () { U.openUrl(S.cfg.site); };
  document.addEventListener('mousedown', function (e) {
    var m = $('#menu');
    if (!m.classList.contains('hidden') && !m.contains(e.target) && !e.target.closest('#menuBtn')) m.classList.add('hidden');
  });
  document.addEventListener('keydown', function (e) {
    var tag = (e.target.tagName || '').toLowerCase();
    var typing = tag === 'input' || tag === 'textarea' || tag === 'select';
    if (e.key === 'Escape') {
      if (U.closeTopSheet()) { e.preventDefault(); return; }
      if (!$('#menu').classList.contains('hidden')) { $('#menu').classList.add('hidden'); return; }
      if (!$('#card').classList.contains('hidden')) { closeCard(); return; }
    }
    // בתוך החלונית הצפה: Alt+M ממזער גם כשהפוקוס כאן (content/float.js מאזין).
    if (e.altKey && e.code === 'KeyM' && document.body.classList.contains('embed')) { e.preventDefault(); window.parent.postMessage({ maakav: 'toggle' }, '*'); return; }
    if (e.key === '/' && !typing && !$('#app').classList.contains('hidden') && !document.querySelector('.sheet-back')) {
      e.preventDefault(); closeCard(); $('#q').focus();
    }
  });
  // ההתראות מתעדכנות ברקע — הפעמון מתעדכן גם כשהחלון פתוח.
  try { chrome.storage.onChanged.addListener(function (ch) { if (ch.feedState && S.prof.role) updBell(); }); } catch (e) { /* בלי storage */ }

  Promise.resolve().then(boot);   // אחרי שה-App הוגדר — המסכים ב-views/ ניגשים אליו

  return {
    S: S, go: go, openCard: openCard, activeStudents: activeStudents, studentById: studentById,
    className: className, classChips: classChips, bindClassChips: bindClassChips, behaviorSheet: behaviorSheet,
  };
})();
