// background.js — שירות הרקע: בודק כל דקה אם מישהו מהצוות הזין נתון חדש,
// ומקפיץ התראה על המסך. רק מנהל ומפקח מקבלים התראות (גם ה-RLS בשרת אוכף את זה).
/* global INSTANCES, NOTIFY_ROLES, Api */
importScripts('lib/config.js', 'lib/api.js');

var POLL_MIN = 1;      // דקה — המינימום ש-Chrome מאפשר לתוסף ארוז
var MAX_POPUPS = 3;    // מעבר לזה — התראה מסכמת אחת, כדי לא להציף
var KEEP = 80;         // כמה פריטים לשמור ברשימה

function nowIso() { return new Date().toISOString(); }

async function getState() {
  var d = await Api.store(['feedState', 'prefs']);
  return { feed: d.feedState || {}, prefs: Object.assign({ notify: true, muted: {} }, d.prefs || {}) };
}

async function setBadge() {
  var st = await getState();
  var n = 0;
  Object.keys(st.feed).forEach(function (k) { n += (st.feed[k].unread || 0); });
  chrome.action.setBadgeBackgroundColor({ color: '#c0392b' });
  chrome.action.setBadgeText({ text: n ? String(n > 99 ? '99+' : n) : '' });
}

function lineOf(it) {
  var who = it.actor_name || 'איש צוות';
  var what = it.title || 'רישום חדש';
  var stu = it.student_name ? ' · ' + it.student_name : '';
  return who + ' — ' + what + stu;
}

async function notifyItems(instKey, items) {
  var cfg = INSTANCES[instKey];
  var icon = chrome.runtime.getURL('icons/icon128.png');
  if (items.length <= MAX_POPUPS) {
    items.forEach(function (it) {
      chrome.notifications.create('feed:' + instKey + ':' + (it.student_id || 0), {
        type: 'basic', iconUrl: icon, title: cfg.name + ' · ' + (it.title || 'רישום חדש'),
        message: (it.actor_name || 'איש צוות') + (it.student_name ? ' — ' + it.student_name : '') +
                 (it.detail ? '\n' + it.detail : ''),
        priority: 1,
      });
    });
  } else {
    chrome.notifications.create('feedsum:' + instKey, {
      type: 'basic', iconUrl: icon,
      title: cfg.name + ' · ' + items.length + ' רישומים חדשים',
      message: items.slice(0, 4).map(lineOf).join('\n'),
      priority: 1,
    });
  }
}

async function pollInstance(instKey, st) {
  var sess = (await Api.sessions())[instKey];
  if (!sess) return;
  // התראות רק למי שהמערכת מגדירה כמנהל/מפקח.
  if (NOTIFY_ROLES.indexOf(sess.role) === -1) return;

  var cur = st.feed[instKey] || { lastId: null, unread: 0, items: [] };
  var rows;
  try {
    rows = await Api.q.feed(instKey, cur.lastId, cur.lastId ? 50 : 30);
  } catch (e) {
    cur.error = String(e.message || e); cur.checkedAt = nowIso();
    st.feed[instKey] = cur; return;
  }
  cur.error = null;
  cur.checkedAt = nowIso();
  rows = rows || [];

  if (cur.lastId === null || cur.lastId === undefined) {
    // הרצה ראשונה — רק קובעים נקודת פתיחה, בלי מבול התראות על העבר.
    cur.lastId = rows.length ? rows[0].id : 0;
    cur.items = rows.slice(0, KEEP);
    cur.unread = 0;
    st.feed[instKey] = cur;
    return;
  }

  if (rows.length) {
    var mine = sess.user_id;
    var fresh = rows.filter(function (r) { return r.actor !== mine; });   // לא מתריעים על מה שאני עצמי הזנתי
    cur.lastId = rows[0].id;
    cur.items = rows.concat(cur.items || []).slice(0, KEEP);
    if (fresh.length && st.prefs.notify) {
      cur.unread = (cur.unread || 0) + fresh.length;
      await notifyItems(instKey, fresh);
    }
  }
  st.feed[instKey] = cur;
}

async function pollAll() {
  var st = await getState();
  var keys = Object.keys(INSTANCES);
  for (var i = 0; i < keys.length; i++) await pollInstance(keys[i], st);
  await Api.save({ feedState: st.feed });
  await setBadge();
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.alarms.create('poll', { periodInMinutes: POLL_MIN, delayInMinutes: 0.1 });
  pollAll();
});
chrome.runtime.onStartup.addListener(function () {
  chrome.alarms.create('poll', { periodInMinutes: POLL_MIN });
  pollAll();
});
chrome.alarms.onAlarm.addListener(function (a) { if (a.name === 'poll') pollAll(); });

chrome.notifications.onClicked.addListener(function (id) {
  var p = id.split(':');
  var url = chrome.runtime.getURL('popup.html?tab=feed&inst=' + (p[1] || ''));
  if (p[0] === 'feed' && p[2] && p[2] !== '0') url += '&student=' + p[2];
  chrome.tabs.create({ url: url });
  chrome.notifications.clear(id);
});

chrome.runtime.onMessage.addListener(function (msg, _s, reply) {
  if (msg && msg.type === 'poll') { pollAll().then(function () { reply({ ok: true }); }); return true; }
  if (msg && msg.type === 'markRead') {
    Api.store(['feedState']).then(function (d) {
      var f = d.feedState || {};
      if (msg.inst && f[msg.inst]) f[msg.inst].unread = 0;
      else Object.keys(f).forEach(function (k) { f[k].unread = 0; });
      Api.save({ feedState: f }).then(function () { setBadge().then(function () { reply({ ok: true }); }); });
    });
    return true;
  }
  return false;
});
