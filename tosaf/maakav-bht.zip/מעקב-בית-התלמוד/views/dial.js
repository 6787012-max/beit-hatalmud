// dial.js — חייגן ואנשי קשר (contacts + calls). למנהל בלבד — כך גם ה-RLS במסד
// (contacts_*_admin). החיוג עובר דרך שרת מקומי (dial_server.py על 127.0.0.1:8770),
// כי הסיסמה של המרכזייה אסור שתהיה בקוד שרץ בדפדפן.
/* global UI, Api, App */
var Dial = (function () {
  'use strict';
  var U = UI, $ = U.$, $$ = U.$$, esc = U.esc, icon = U.icon;
  var SERVER = 'http://127.0.0.1:8770';
  // שלוחות במרכזייה. יוסף = 201, וינברג = 200. שלוחה חדשה — רק לרשום כאן.
  var EXTENSIONS = [{ code: '201', label: 'השלוחה שלי (201)' }, { code: '200', label: 'הרב וינברג (200)' }];
  // snumber לפי שלוחה: הקבוע היחיד שאדל שלחה. אם יגיעו נפרדים — לרשום כאן.
  var SNUM = { '200': '7090473485', '201': '7090473485' };
  var SRC = { mechina: 'הורי מכינה', gmail: 'מהמייל', weinberg: 'אצל וינברג', manual: 'ידני' };
  var st = { contacts: [], loaded: false, server: null, q: '', src: '' };

  var norm = function (p) { return (p || '').replace(/[^\d+]/g, ''); };

  async function checkServer() {
    try { var r = await fetch(SERVER + '/health'); st.server = r.ok; } catch (e) { st.server = false; }
    return st.server;
  }
  async function load(force) {
    if (st.loaded && !force) return;
    st.contacts = await Api.q.contacts(App.S.inst);
    st.loaded = true;
  }

  async function render(host) {
    host.innerHTML =
      '<div class="toolbar"><div class="search-in">' + icon('search') + '<input id="cnQ" class="inp" type="search" placeholder="שם או טלפון…" value="' + esc(st.q) + '"></div>' +
        '<select id="cnSrc" class="inp mini">' + U.options(Object.keys(SRC).map(function (k) { return { v: k, t: SRC[k] }; }), st.src, 'כל המקורות') + '</select></div>' +
      '<div class="btn-row"><button class="btn sm primary" id="cnNew">' + icon('plus') + '<span>איש קשר</span></button>' +
        '<button class="btn sm" id="cnImp">' + icon('download') + '<span>יבוא</span></button>' +
        '<span class="grow"></span><span class="chip" id="cnSrv">שרת חיוג: בודק…</span></div>' +
      '<div id="cnList" class="list">' + U.loading() + '</div>';
    $('#cnQ', host).oninput = function () { st.q = this.value; paint(host); };
    $('#cnSrc', host).onchange = function () { st.src = this.value; paint(host); };
    $('#cnNew', host).onclick = function () { newSheet(host); };
    $('#cnImp', host).onclick = function () { importSheet(host); };
    checkServer().then(function (ok) {
      var b = $('#cnSrv', host); if (!b) return;
      b.textContent = ok ? 'שרת חיוג: פועל' : 'שרת חיוג: כבוי';
      b.className = 'chip ' + (ok ? 'ok' : 'bad');
      if (!ok) b.title = 'להפעיל: pyw C:/projects/maakav/dial_server/dial_server.py';
    });
    try { await load(); paint(host); }
    catch (e) { $('#cnList', host).innerHTML = U.empty('x', 'טעינת אנשי הקשר נכשלה', esc(e.message)); }
  }

  function paint(host) {
    var t = st.q.trim(), nt = norm(t);
    var list = st.contacts.filter(function (c) {
      if (st.src && c.source !== st.src) return false;
      if (!t) return true;
      return (c.name || '').indexOf(t) > -1 || (nt && norm(c.phone).indexOf(nt) > -1);
    });
    var box = $('#cnList', host);
    if (!list.length) { box.innerHTML = U.empty('phone', 'אין אנשי קשר תואמים', 'אפשר להוסיף חדש או לייבא את הורי המכינה.'); return; }
    box.innerHTML = '<div class="list-h">' + list.length + ' אנשי קשר</div>' + list.slice(0, 200).map(function (c) {
      return '<div class="row" data-id="' + c.id + '">' + U.avatar(c.name) +
        '<div class="grow"><b>' + esc(c.name) + '</b><div class="meta" dir="auto">' + esc(c.phone) + ' · ' + esc(SRC[c.source] || c.source || '') +
          (c.notes ? ' · ' + esc(c.notes) : '') + '</div></div>' +
        '<button class="btn sm primary cn-dial" data-id="' + c.id + '">' + icon('phone') + '<span>חיוג</span></button>' +
        '<button class="ic-btn sm danger cn-del" data-id="' + c.id + '" title="מחיקה">' + icon('trash') + '</button></div>';
    }).join('') + (list.length > 200 ? '<div class="hint">מוצגים 200 ראשונים מתוך ' + list.length + '. חיפוש מצמצם.</div>' : '');
    $$('.cn-dial', box).forEach(function (b) { b.onclick = function () { dialContact(b.dataset.id); }; });
    $$('.cn-del', box).forEach(function (b) {
      b.onclick = async function () {
        if (!(await U.confirm('למחוק את איש הקשר?', 'מחיקה', true))) return;
        try { await Api.q.delContact(App.S.inst, b.dataset.id); U.toast('נמחק'); await load(true); paint(host); }
        catch (e) { U.toast('המחיקה נכשלה: ' + e.message, true); }
      };
    });
  }

  function pickExt(cb) {
    var s = U.sheet({
      title: 'ממי לחייג?',
      body: EXTENSIONS.map(function (e) { return '<button class="btn block ext-o" data-c="' + e.code + '">' + icon('phone') + '<span>' + esc(e.label) + '</span></button>'; }).join(''),
    });
    $$('.ext-o', s.el).forEach(function (b) { b.onclick = function () { s.close(); cb(b.dataset.c); }; });
  }

  function dialContact(cid) {
    var c = st.contacts.filter(function (x) { return String(x.id) === String(cid); })[0];
    if (!c) return U.toast('איש הקשר לא נמצא', true);
    pickExt(function (ext) { perform(norm(c.phone), ext, c); });
  }
  // חיוג למספר חופשי (מכרטיס התלמיד — טלפון של הורה)
  function dialNumber(phone, name, studentId) {
    pickExt(function (ext) { perform(norm(phone), ext, { id: null, name: name, student_id: studentId }); });
  }

  async function perform(cnumber, ext, contact) {
    if (!cnumber) return U.toast('אין מספר לחיוג', true);
    U.toast('מחייג ל' + (contact && contact.name ? contact.name : cnumber) + '…');
    try {
      var r = await fetch(SERVER + '/dial', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cnumber: cnumber, snumber: SNUM[ext] || null }),
      });
      var j = await r.json().catch(function () { return {}; });
      if (!r.ok) throw new Error(j.error || 'שגיאת שרת');
      // אדל מחזירים 200 להצלחה או 201 לתגובה חלופית — שניהם תקינים.
      var ok = j.status === 200 || j.status === 201;
      U.toast(ok ? 'המרכזייה מחייגת — הטלפון שלך יצלצל' : 'שגיאה: HTTP ' + j.status, !ok);
      try {
        await Api.q.addCall(App.S.inst, {
          contact_id: contact ? contact.id : null, student_id: contact ? contact.student_id : null,
          direction: 'out', from_ext: ext, to_number: cnumber, contact_name: contact ? contact.name : null,
          status: ok ? 'ok' : 'failed', created_by: App.S.prof.id,
        });
      } catch (e) { /* רישום השיחה לא קריטי */ }
    } catch (e) {
      U.toast(st.server === false ? 'שרת החיוג לא פועל (dial_server.py)' : 'החיוג נכשל: ' + e.message, true);
    }
  }

  function newSheet(host) {
    U.sheet({
      title: 'איש קשר חדש',
      body: '<div class="form">' + U.field('cnName', 'שם', 'text', { full: true, req: true, autofocus: true }) +
        U.field('cnPhone', 'טלפון', 'tel', { req: true, dir: 'ltr' }) + U.field('cnNotes', 'הערה', 'text', { ph: 'לא חובה' }) + '</div>',
      onSave: async function (el, api) {
        var name = $('#cnName', el).value.trim(), phone = norm($('#cnPhone', el).value);
        if (!name || !phone) { api.msg('חובה להזין שם וטלפון'); return false; }
        await Api.q.addContact(App.S.inst, { name: name, phone: phone, source: 'manual', notes: $('#cnNotes', el).value.trim() || null, created_by: App.S.prof.id });
        U.toast('נוסף'); await load(true); paint(host); return true;
      },
    });
  }

  function importSheet(host) {
    var s = U.sheet({
      title: 'יבוא אנשי קשר',
      body: '<p class="hint">מייבא רק מי שעוד לא קיים (לפי מספר הטלפון).</p>' +
        '<button class="btn block" id="impM">' + icon('users') + '<span>הורי המכינה (אב ואם מכל תלמיד)</span></button>' +
        '<button class="btn block" id="impG">' + icon('download') + '<span>מהמייל שלי (Google Contacts)</span></button>' +
        '<div class="form-msg" id="impMsg"></div>',
    });
    var msg = $('#impMsg', s.el);
    $('#impG', s.el).onclick = function () {
      msg.className = 'form-msg'; msg.textContent = 'היבוא מגוגל רץ מהמחשב: python C:/projects/maakav/dial_server/import_gmail.py — אחריו רענון כאן.';
    };
    $('#impM', s.el).onclick = async function () {
      msg.className = 'form-msg'; msg.textContent = 'שולף תלמידים…';
      try {
        var rows = await Api.q.studentsParents(App.S.inst);
        var have = {}; st.contacts.forEach(function (c) { have[norm(c.phone)] = true; });
        var add = [];
        rows.forEach(function (x) {
          var fam = x.family || '';
          function push(name, phone, kind) {
            var p = norm(phone);
            if (!p || p.length < 7 || have[p]) return;
            have[p] = true;
            var full = (name || fam || x.name || '').trim() + (fam && name && name.indexOf(fam) === -1 ? ' ' + fam : '') + ' (' + kind + ' של ' + x.name + ')';
            add.push({ name: full, phone: p, source: 'mechina', student_id: x.id, notes: null, created_by: App.S.prof.id });
          }
          push(x.parent_name, x.parent_phone, 'אבא');
          push(x.mother_name, x.mother_phone, 'אמא');
        });
        if (!add.length) { msg.className = 'form-msg ok'; msg.textContent = 'כל ההורים כבר קיימים.'; return; }
        var added = 0;
        for (var i = 0; i < add.length; i += 100) {
          try { await Api.q.addContact(App.S.inst, add.slice(i, i + 100)); added += Math.min(100, add.length - i); }
          catch (e) { /* קבוצה שנכשלה — כפילות */ }
        }
        msg.className = 'form-msg ok'; msg.textContent = 'נוספו ' + added + ' מתוך ' + add.length + '.';
        await load(true); paint(host);
      } catch (e) { msg.className = 'form-msg bad'; msg.textContent = 'היבוא נכשל: ' + e.message; }
    };
  }

  return { render: render, dialNumber: dialNumber, checkServer: checkServer };
})();
