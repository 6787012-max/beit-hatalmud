// passport.js — דרכון (בית התלמוד בלבד: INSTANCES[inst].features.passport).
// מסך הזנה מהיר לפי שבוע, פאנל בכרטיס התלמיד, וכרטיס התקדמות במסך הבית.
/* global UI, Api, App */
var Passport = (function () {
  'use strict';
  var U = UI, $ = U.$, $$ = U.$$, esc = U.esc, icon = U.icon;

  // ---- לוח השבועות — חייב להיות זהה אחד-לאחד ל-js/passport.js באתר ----
  // week_no הוא המפתח המשותף במסד: שבוע 7 כאן = שבוע 7 שם. 18/10/2026: הרשימה שהיתה
  // כאן היתה של שנה אחרת (ניצבים/וילך/סוכות/בראשית כשבועות נפרדים), כלומר הזנה מהתוסף
  // נרשמה לפרשה אחרת מבאתר. בשנה הבאה — לעדכן את WEEKS ואת SHABBAT יחד, בשני המקומות.
  var WEEKS = [
    ['כי תצא', 'ט׳ אלול'], ['כי תבוא', 'ט״ז אלול'], ['נצבים־וילך', 'כ״ג אלול'],
    ['ראש השנה', 'א׳ תשרי'], ['האזינו', 'ח׳ תשרי'],
    ['נח', 'ו׳ חשון'], ['לך־לך', 'י״ג חשון'], ['וירא', 'כ׳ חשון'], ['חיי שרה', 'כ״ז חשון'],
    ['תולדות', 'ד׳ כסליו'], ['ויצא', 'י״א כסליו'], ['וישלח', 'י״ח כסליו'], ['וישב', 'כ״ה כסליו'],
    ['מקץ', 'ב׳ טבת'], ['ויגש', 'ט׳ טבת'], ['ויחי', 'ט״ז טבת'], ['שמות', 'כ״ג טבת'],
    ['וארא', 'א׳ שבט'], ['בא', 'ח׳ שבט'], ['בשלח', 'ט״ו בשבט'], ['יתרו', 'כ״ב שבט'],
    ['משפטים', 'כ״ט שבט'],
  ];
  var SHABBAT = ['2026-08-22', '2026-08-29', '2026-09-05', '2026-09-12', '2026-09-19', '2026-10-17', '2026-10-24', '2026-10-31', '2026-11-07', '2026-11-14', '2026-11-21', '2026-11-28', '2026-12-05', '2026-12-12', '2026-12-19', '2026-12-26', '2027-01-02', '2027-01-09', '2027-01-16', '2027-01-23', '2027-01-30', '2027-02-06'];

  // השבוע הנוכחי = השבת האחרונה שכבר הגיעה (זהה לאתר). לפני השבת הראשונה — שבוע 1.
  function currentWeek() {
    var today = new Date(); today.setHours(23, 59, 59, 999);
    var w = 1;
    SHABBAT.forEach(function (d, i) { var p = d.split('-'); if (new Date(+p[0], +p[1] - 1, +p[2]) <= today) w = i + 1; });
    return Math.min(w, WEEKS.length);
  }

  // ניקוד 0–100 ושכר בש"ח — הועתקו מ-js/passport.js באתר (score / shekels), לתצוגה בלבד.
  function score(r) {
    if (!r) return null;
    var parts = [];
    if (r.shacharit != null) parts.push(Math.min(100, (r.shacharit / 6) * 100));
    if (r.study_min != null) parts.push(Math.min(100, (r.study_min / 120) * 100));
    if (r.test_written != null) parts.push(Math.min(100, r.test_written));
    if (r.test_oral != null) parts.push(Math.min(100, r.test_oral));
    return parts.length ? Math.round(parts.reduce(function (a, b) { return a + b; }, 0) / parts.length) : null;
  }
  var shcShacharit = function (d) { return d == null || d < 5 ? 0 : d === 5 ? 1 : 2 + (d - 6); };
  var shcStudy = function (m) {
    if (m == null || m < 20) return 0;
    if (m < 40) return 1;
    if (m < 60) return 1.5;
    if (m < 80) return 3;
    if (m < 100) return 4;
    return 4 + 2 * Math.floor((m - 80) / 20);
  };
  var shcTest = function (t) { return t == null || t < 80 ? 0 : t < 90 ? 1 : t < 100 ? 2 : 3; };
  var shcKinyan = function (v) { var n = String(v == null ? '' : v).replace(/\s+/g, ''); return n === 'א+' ? 2.5 : n === 'א' ? 1.5 : 0; };
  function shekels(r) {
    if (!r) return 0;
    return shcShacharit(r.shacharit) + shcStudy(r.study_min) + shcTest(r.test_written) + shcTest(r.test_oral) + shcKinyan(r.kinyan_rashi);
  }
  var fmtShc = function (v) { return (Math.round(v * 10) / 10).toString().replace(/\.0$/, ''); };

  // המקסימום של המבחנים = 100 כמו ה-CHECK במסד (passport_range). האתר מרשה 120 בטופס
  // ונכשל מול המסד — כאן לא משכפלים את הפער.
  var FIELDS = [
    { k: 'shacharit', t: 'שחרית בזמן', sub: 'ימים', max: 7 },
    { k: 'study_min', t: 'לימוד בשב״ק', sub: 'דקות', max: 1440 },
    { k: 'test_written', t: 'מבחן בכתב', sub: '0–100', max: 100 },
    { k: 'test_oral', t: 'מבחן בע״פ', sub: '0–100', max: 100 },
  ];
  var KINYAN = [{ v: '', t: 'לא' }, { v: 'א', t: 'א' }, { v: 'א+', t: 'א+' }];

  var st = { week: null, data: {}, cls: '', missing: false, open: null };

  function weekTitle(w) { return 'פרשת ' + WEEKS[w - 1][0]; }
  function weekSub(w) { return 'שבוע ' + w + ' · ' + WEEKS[w - 1][1] + ' · ' + U.fmtDate(SHABBAT[w - 1]); }
  function scoreChip(sc) {
    return '<span class="chip ' + (sc == null ? 'mute' : sc >= 85 ? 'ok' : 'neutral') + '" title="ניקוד שבועי">' + (sc == null ? 'ריק' : sc) + '</span>';
  }
  function shcChip(r) {
    var v = shekels(r);
    var tip = 'שחרית ' + shcShacharit(r.shacharit) + ' · לימוד ' + shcStudy(r.study_min) + ' · בכתב ' + shcTest(r.test_written) +
      ' · בע״פ ' + shcTest(r.test_oral) + ' · קנין רש״י ' + shcKinyan(r.kinyan_rashi);
    return '<span class="chip ' + (v > 0 ? 'gold' : 'mute') + '" title="' + esc(tip) + '">' + fmtShc(v) + ' ₪</span>';
  }
  function filled(r) {
    return !!r && FIELDS.some(function (f) { return r[f.k] != null; }) || !!(r && r.kinyan_rashi);
  }

  async function loadWeek() {
    var rows = await Api.q.passportByWeek(App.S.inst, st.week);
    st.data = {};
    (rows || []).forEach(function (r) { st.data[r.student_id] = r; });
  }

  function list() {
    return App.activeStudents().filter(function (s) {
      if (st.cls && String(s.class_id) !== st.cls) return false;
      if (st.missing && filled(st.data[s.id])) return false;
      return true;
    });
  }

  // ================= המסך =================
  async function render(host) {
    if (st.week == null) st.week = currentWeek();
    var all = App.activeStudents();
    host.innerHTML =
      '<div class="weekbar">' +
        '<button class="ic-btn" id="pwPrev" title="השבוע הקודם">' + icon('chevR') + '</button>' +
        '<div class="weekbar-t"><b id="pwTitle"></b><small id="pwSub"></small></div>' +
        '<button class="ic-btn" id="pwNext" title="השבוע הבא">' + icon('chevL') + '</button>' +
        '<select id="pwSel" class="inp mini" title="בחירת שבוע">' +
          WEEKS.map(function (w, i) { return '<option value="' + (i + 1) + '">' + (i + 1) + '. ' + esc(w[0]) + '</option>'; }).join('') +
        '</select>' +
      '</div>' +
      '<div class="chips scroll" id="pwCls">' + App.classChips(st.cls, all) + '</div>' +
      '<div class="progress-row"><div class="progress"><i id="pwBar"></i></div><span id="pwCount"></span>' +
        '<label class="switch"><input type="checkbox" id="pwMissing"' + (st.missing ? ' checked' : '') + '><span>רק מי שחסר</span></label></div>' +
      '<div id="pwList" class="list">' + U.loading() + '</div>';

    function setWeek(w) {
      st.week = Math.max(1, Math.min(WEEKS.length, w)); st.open = null;
      $('#pwTitle', host).textContent = weekTitle(st.week);
      $('#pwSub', host).textContent = weekSub(st.week) + (st.week === currentWeek() ? ' · השבוע' : '');
      $('#pwSel', host).value = String(st.week);
      $('#pwPrev', host).disabled = st.week <= 1; $('#pwNext', host).disabled = st.week >= WEEKS.length;
      $('#pwList', host).innerHTML = U.loading();
      loadWeek().then(function () { paint(host); }, function (e) {
        $('#pwList', host).innerHTML = U.empty('x', 'טעינת הדרכון נכשלה', esc(e.message));
      });
    }
    $('#pwPrev', host).onclick = function () { setWeek(st.week - 1); };
    $('#pwNext', host).onclick = function () { setWeek(st.week + 1); };
    $('#pwSel', host).onchange = function () { setWeek(Number(this.value)); };
    $('#pwMissing', host).onchange = function () { st.missing = this.checked; st.open = null; paint(host); };
    App.bindClassChips($('#pwCls', host), function (v) { st.cls = v; st.open = null; paint(host); });
    setWeek(st.week);
  }

  function paint(host) {
    var box = $('#pwList', host); if (!box) return;
    var base = App.activeStudents().filter(function (s) { return !st.cls || String(s.class_id) === st.cls; });
    var done = base.filter(function (s) { return filled(st.data[s.id]); }).length;
    $('#pwCount', host).textContent = 'הוזנו ' + done + ' מתוך ' + base.length;
    $('#pwBar', host).style.width = (base.length ? Math.round(done / base.length * 100) : 0) + '%';
    var rows = list();
    if (!rows.length) {
      box.innerHTML = st.missing ? U.empty('check', 'כולם הוזנו לשבוע הזה', 'אפשר לבטל את "רק מי שחסר" כדי לראות את כולם.')
        : U.empty('users', 'אין תלמידים פעילים בכיתה שנבחרה');
      return;
    }
    box.innerHTML = rows.map(function (s) {
      var r = st.data[s.id];
      var isOpen = String(st.open) === String(s.id);
      return '<div class="row psp-row' + (isOpen ? ' open' : '') + (filled(r) ? '' : ' missing') + '" data-id="' + s.id + '">' +
        U.avatar(s.name) +
        '<div class="grow"><b>' + esc(s.name) + '</b><div class="meta">' + esc(App.className(s.class_id) || 'ללא כיתה') +
          (r && r.kinyan_rashi ? ' · קנין רש״י ' + esc(r.kinyan_rashi) : '') + '</div></div>' +
        (r ? shcChip(r) : '') + scoreChip(score(r)) +
        '</div>' + (isOpen ? editor(s, r || {}) : '');
    }).join('');
    $$('.psp-row', box).forEach(function (el) {
      el.onclick = function () {
        st.open = String(st.open) === el.dataset.id ? null : el.dataset.id;
        paint(host);
        var ed = $('.psp-ed', box);
        if (ed) { ed.scrollIntoView({ block: 'nearest' }); var f = $('input', ed); if (f) f.focus(); }
      };
    });
    var ed = $('.psp-ed', box);
    if (ed) bindEditor(ed, host, rows);
  }

  function editor(s, r) {
    return '<div class="psp-ed">' +
      '<div class="psp-grid">' + FIELDS.map(function (f) {
        return '<label class="fld"><span class="lbl">' + esc(f.t) + ' <em>' + esc(f.sub) + '</em></span>' +
          '<input class="inp num" type="number" inputmode="numeric" min="0" max="' + f.max + '" data-k="' + f.k + '" value="' + (r[f.k] != null ? r[f.k] : '') + '"></label>';
      }).join('') + '</div>' +
      '<div class="fld"><span class="lbl">בדיקת מחברות קנין רש״י</span>' + U.seg('psKr', KINYAN, r.kinyan_rashi || '') + '</div>' +
      '<div class="psp-act"><button type="button" class="btn primary" data-act="next">' + icon('check') + '<span>שמירה והבא</span></button>' +
        '<button type="button" class="btn" data-act="save">שמירה</button>' +
        '<span class="form-msg"></span></div>' +
      '<div class="hint">Enter עובר לשדה הבא · Enter בשדה האחרון = שמירה והבא</div>' +
    '</div>';
  }

  function readEditor(ed) {
    var row = {}, err = '';
    $$('input[data-k]', ed).forEach(function (inp) {
      var f = FIELDS.filter(function (x) { return x.k === inp.dataset.k; })[0];
      var v = inp.value.trim();
      if (v === '') { row[f.k] = null; return; }
      var n = Number(v);
      if (!isFinite(n) || n < 0 || n !== Math.floor(n)) { err = err || (f.t + ': מספר שלם בלבד'); return; }
      if (n > f.max) { err = err || (f.t + ': עד ' + f.max); return; }
      row[f.k] = n;
    });
    row.kinyan_rashi = U.segVal(ed, 'psKr') || null;
    return { row: row, err: err };
  }

  function bindEditor(ed, host, rows) {
    U.bindSeg(ed);
    ed.addEventListener('click', function (e) { e.stopPropagation(); });
    var inputs = $$('input[data-k]', ed);
    inputs.forEach(function (inp, i) {
      inp.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        if (i < inputs.length - 1) { inputs[i + 1].focus(); inputs[i + 1].select(); } else save(true);
      });
    });
    $$('[data-act]', ed).forEach(function (b) { b.onclick = function () { save(b.dataset.act === 'next'); }; });

    async function save(next) {
      var msg = $('.form-msg', ed);
      var res = readEditor(ed);
      if (res.err) { msg.textContent = res.err; msg.className = 'form-msg bad'; return; }
      var sid = Number(st.open);
      var w = WEEKS[st.week - 1];
      var row = Object.assign({ student_id: sid, week_no: st.week, parasha: w[0], heb_date: w[1] }, res.row);
      $$('[data-act]', ed).forEach(function (b) { b.disabled = true; });
      msg.textContent = 'שומר…'; msg.className = 'form-msg';
      try {
        var out = await Api.q.upsertPassport(App.S.inst, row);
        st.data[sid] = (out && out[0]) || row;
        U.toast('נשמר לפרשת ' + w[0]);
        if (next) {
          var ids = rows.map(function (s) { return String(s.id); });
          var at = ids.indexOf(String(sid));
          // "רק מי שחסר": מי שנשמר יורד מהרשימה, ולכן הבא הוא מי שתפס את מקומו.
          var nextId = ids[at + 1] || null;
          st.open = nextId;
        } else st.open = null;
        paint(host);
        var ned = $('.psp-ed', host);
        if (ned) { ned.scrollIntoView({ block: 'nearest' }); var f = $('input', ned); if (f) { f.focus(); f.select(); } }
      } catch (e) {
        msg.textContent = 'השמירה נכשלה: ' + e.message; msg.className = 'form-msg bad';
        $$('[data-act]', ed).forEach(function (b) { b.disabled = false; });
      }
    }
  }

  // ================= בכרטיס התלמיד =================
  function cardPane(rows) {
    rows = (rows || []).slice().sort(function (a, b) { return b.week_no - a.week_no; });
    if (!rows.length) return U.empty('book', 'אין עדיין נתוני דרכון', 'הוספה בכפתור "דרכון" למעלה.');
    var tot = rows.reduce(function (a, r) { return a + shekels(r); }, 0);
    return '<div class="sum-line">' + rows.length + ' מתוך ' + WEEKS.length + ' שבועות · סה״כ ' + fmtShc(tot) + ' ₪</div>' +
      '<div class="spark">' + WEEKS.map(function (w, i) {
        var r = rows.filter(function (x) { return x.week_no === i + 1; })[0];
        var sc = score(r);
        return '<i title="' + esc((i + 1) + '. ' + w[0] + (sc == null ? ' — ריק' : ' — ' + sc)) + '" style="height:' + (sc == null ? 4 : Math.max(8, sc)) + '%"' +
          (sc == null ? ' class="none"' : sc >= 85 ? ' class="ok"' : '') + '></i>';
      }).join('') + '</div>' +
      rows.map(function (r) {
        var w = WEEKS[r.week_no - 1] || ['שבוע ' + r.week_no, ''];
        return '<div class="mini-row"><div class="grow"><b>' + esc(w[0]) + '</b><div class="meta">' +
          FIELDS.map(function (f) { return r[f.k] != null ? esc(f.t) + ' ' + r[f.k] : ''; }).filter(Boolean).join(' · ') +
          (r.kinyan_rashi ? ' · קנין רש״י ' + esc(r.kinyan_rashi) : '') + '</div></div>' + shcChip(r) + scoreChip(score(r)) + '</div>';
      }).join('');
  }
  function lastScore(rows) {
    rows = (rows || []).slice().sort(function (a, b) { return b.week_no - a.week_no; });
    return rows.length ? score(rows[0]) : null;
  }

  // הזנת דרכון לתלמיד אחד מתוך הכרטיס. onDone() אחרי שמירה.
  function quickSheet(stu, rows, onDone) {
    var wk = currentWeek();
    var byWeek = {}; (rows || []).forEach(function (r) { byWeek[r.week_no] = r; });
    var s = U.sheet({
      title: 'דרכון — ' + stu.name,
      body: '<label class="fld"><span class="lbl">שבוע</span><select id="qsWeek" class="inp">' +
          WEEKS.map(function (w, i) { return '<option value="' + (i + 1) + '"' + (i + 1 === wk ? ' selected' : '') + '>' + (i + 1) + '. פרשת ' + esc(w[0]) + ' · ' + esc(w[1]) + (byWeek[i + 1] ? ' ✓' : '') + '</option>'; }).join('') +
        '</select></label><div id="qsEd"></div>',
      saveLabel: 'שמירה',
      onSave: async function (el, api) {
        var res = readEditor(el);
        if (res.err) { api.msg(res.err); return false; }
        var w = Number($('#qsWeek', el).value);
        var row = Object.assign({ student_id: stu.id, week_no: w, parasha: WEEKS[w - 1][0], heb_date: WEEKS[w - 1][1] }, res.row);
        await Api.q.upsertPassport(App.S.inst, row);
        U.toast('הדרכון נשמר');
        if (onDone) onDone();
        return true;
      },
    });
    function fill() {
      var r = byWeek[Number($('#qsWeek', s.el).value)] || {};
      $('#qsEd', s.el).innerHTML = '<div class="psp-grid">' + FIELDS.map(function (f) {
        return '<label class="fld"><span class="lbl">' + esc(f.t) + ' <em>' + esc(f.sub) + '</em></span>' +
          '<input class="inp num" type="number" inputmode="numeric" min="0" max="' + f.max + '" data-k="' + f.k + '" value="' + (r[f.k] != null ? r[f.k] : '') + '"></label>';
      }).join('') + '</div><div class="fld"><span class="lbl">בדיקת מחברות קנין רש״י</span>' + U.seg('psKr', KINYAN, r.kinyan_rashi || '') + '</div>';
      U.bindSeg(s.el);
    }
    $('#qsWeek', s.el).onchange = fill;
    fill();
  }

  // ================= כרטיס במסך הבית =================
  async function homeCard(host) {
    var w = currentWeek();
    var all = App.activeStudents();
    host.innerHTML = '<div class="tile clickable" id="hpTile"><div class="tile-h">' + icon('book') + '<b>דרכון · ' + esc(weekTitle(w)) + '</b>' +
      '<span class="tile-more">למילוי ' + icon('chevL') + '</span></div><div class="tile-b">' + U.loading() + '</div></div>';
    $('#hpTile', host).onclick = function () { App.go('passport'); };
    try {
      var rows = await Api.q.passportByWeek(App.S.inst, w);
      var ids = {}; all.forEach(function (s) { ids[s.id] = true; });
      var done = (rows || []).filter(function (r) { return ids[r.student_id] && filled(r); }).length;
      var pct = all.length ? Math.round(done / all.length * 100) : 0;
      $('.tile-b', host).innerHTML = '<div class="progress-row"><div class="progress"><i style="width:' + pct + '%"></i></div>' +
        '<span>' + done + ' / ' + all.length + '</span></div><div class="meta">' + esc(weekSub(w)) + '</div>';
    } catch (e) {
      $('.tile-b', host).innerHTML = '<div class="meta bad">' + esc(e.message) + '</div>';
    }
  }

  return {
    WEEKS: WEEKS, SHABBAT: SHABBAT, currentWeek: currentWeek, score: score, shekels: shekels,
    render: render, cardPane: cardPane, lastScore: lastScore, quickSheet: quickSheet, homeCard: homeCard,
  };
})();
