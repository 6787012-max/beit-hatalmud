// prints.js — הדפסות: היתרה שלי, היסטוריה, דיווח הדפסה, טעינה בנדרים פלוס, ולמשרד —
// יתרות כל הצוות. זהה בלוגיקה ובהרשאות ל-js/prints.js באתר: היתרות מחושבות בשרת
// (print_balances), המחיר נקבע בשרת בטריגר, וה-RLS קובע מי רואה ומי כותב מה.
// ניהול מחירים, קישור ה-QR, שיוך תשלומי נדרים ויבוא — נשארים באתר בלבד.
/* global UI, Api, App */
var Prints = (function () {
  'use strict';
  var U = UI, $ = U.$, $$ = U.$$, esc = U.esc, icon = U.icon;
  var COLORS = ['שחור לבן', 'צבעוני'], SIZES = ['A4', 'A3'];
  var st = { tab: null, rows: [], prices: [], me: null, err: null };

  var role = function () { return App.S.prof.role; };
  var isOffice = function () { return ['מנהל', 'מזכירה', 'מפקח'].indexOf(role()) > -1; };   // = is_print_office()
  var canManage = function () { return ['מנהל', 'מזכירה'].indexOf(role()) > -1; };         // = policy print_*_office
  var balCls = function (b) { b = Number(b); return b < 0 ? 'neg' : b < 10 ? 'low' : 'pos'; };
  var priceOf = function (color, size) {
    var p = st.prices.filter(function (x) { return x.color === color && x.size === size; })[0];
    return p ? Number(p.price) : 0;
  };
  function myRow() {
    if (!st.me || !st.me.staff_id) return null;
    return st.rows.filter(function (r) { return String(r.staff_id) === String(st.me.staff_id); })[0] || null;
  }

  // דף התשלום של המכינה בנדרים פלוס, עם קטגוריה "הדפסות" נעולה והערה "הדפסות #<staff_id>" —
  // לפיה ה-Webhook (nedarim-print) יודע למי לטעון. הועתק מ-js/prints.js (nedarimUrl).
  // encodeURIComponent ולא URLSearchParams: האחרון מקודד רווח כ-'+', ונדרים שומרים את ה-'+'.
  function nedarimUrl(mosad, groupe, staffId, name) {
    var q = { mosad: mosad, Groupe: groupe, GroupeLock: '1', OnlyNormal: '1' };
    if (staffId) q.Avour = groupe + ' #' + staffId;
    if (name) q.ClientName = name;
    return 'https://www.matara.pro/nedarimplus/online/?' + Object.keys(q).map(function (k) { return k + '=' + encodeURIComponent(q[k]); }).join('&');
  }
  function payUrl() { var m = st.me; return m && m.staff_id && m.mosad ? nedarimUrl(m.mosad, m.groupe, m.staff_id, m.name) : null; }

  async function load() {
    var inst = App.S.inst;
    var res = await Promise.all([
      Api.q.printBalances(inst).then(function (r) { return { ok: true, d: r || [] }; }, function (e) { return { ok: false, e: e.message }; }),
      Api.q.printPrices(inst).catch(function () { return []; }),
      Api.q.printMe(inst).catch(function () { return null; }),
    ]);
    st.err = res[0].ok ? null : res[0].e;
    st.rows = res[0].d || []; st.prices = res[1] || []; st.me = res[2];
  }

  // ================= המסך =================
  async function render(host) {
    host.innerHTML = U.loading('טוען יתרות…');
    await load();
    if (st.err) { host.innerHTML = U.empty('x', 'מסך ההדפסות לא זמין', esc(st.err)); return; }
    var mine = myRow();
    if (!st.tab) st.tab = mine ? 'mine' : 'team';
    if (!mine) st.tab = 'team';
    if (!isOffice()) st.tab = 'mine';
    if (!isOffice() && !mine) {
      host.innerHTML = U.empty('user', 'אין לך חשבון הדפסות', 'המשתמש שלך לא מקושר לאיש צוות ברשימת הצוות. יש לפנות למזכירות.');
      return;
    }
    host.innerHTML = (isOffice() && mine ? U.seg('prTab', [{ v: 'mine', t: 'היתרה שלי' }, { v: 'team', t: 'יתרות הצוות' }], st.tab, { cls: 'tabs-seg' }) : '') +
      '<div id="prBody"></div>';
    U.bindSeg(host, function (id, v) { st.tab = v; draw(); });
    function draw() {
      var b = $('#prBody', host);
      if (st.tab === 'mine' && mine) renderMine(b, mine, host); else renderTeam(b, host);
    }
    draw();
  }

  function balanceHero(r) {
    var b = Number(r.balance);
    return '<div class="hero ' + balCls(b) + '"><div class="hero-l">' + icon('wallet') + '<span>היתרה שלי</span></div>' +
      '<div class="hero-v">' + U.money(b) + '</div>' +
      (b < 0 ? '<div class="hero-warn">אין יתרה — יש לטעון</div>' : b < 10 ? '<div class="hero-warn">היתרה נמוכה</div>' : '') +
      '<div class="hero-stats"><span><small>נטען</small>' + U.money(r.credits) + '</span><span><small>הודפס</small>' + U.money(r.used) + '</span>' +
      '<span><small>עמודים</small>' + U.num(r.pages) + '</span></div></div>';
  }
  function pricesLine() {
    if (!st.prices.length) return '';
    return '<div class="prices"><span>מחיר לעמוד</span>' + SIZES.map(function (s) {
      return COLORS.map(function (c) { return '<span class="chip">' + s + ' ' + c + ' <b>' + U.money(priceOf(c, s)) + '</b></span>'; }).join('');
    }).join('') + '</div>';
  }

  function renderMine(box, r, root) {
    var url = payUrl();
    box.innerHTML = balanceHero(r) +
      '<div class="btn-row"><button class="btn primary" id="prJob">' + icon('printer') + '<span>דיווח הדפסה</span></button>' +
        (url ? '<button class="btn" id="prPay">' + icon('card') + '<span>טעינה בנדרים פלוס</span></button>' : '') + '</div>' +
      (url ? '<div class="hint">התשלום בנדרים פלוס נטען ליתרה לבד תוך דקה. טעינה במזומן — במזכירות.</div>' : '') +
      pricesLine() +
      '<h4 class="sec-h">' + icon('clock') + 'היסטוריה</h4><div id="prHist">' + U.loading() + '</div>';
    $('#prJob', box).onclick = function () { jobSheet(r, false, function () { render(root); }); };
    if (url) $('#prPay', box).onclick = function () { U.openUrl(url); };
    drawHistory($('#prHist', box), r, false, function () { render(root); });
  }

  function sortRows(rows) {
    // הפעילים למעלה (כמו באתר): צוות פעיל עם תנועות לפי ההדפסה האחרונה, אחריו פעיל בלי
    // תנועות, ובסוף מי שהושבת ונשארה לו יתרה.
    var act = function (r) { return (Number(r.jobs) > 0 || Number(r.credits) !== 0) ? 1 : 0; };
    return rows.slice().sort(function (a, b) {
      return ((b.active ? 1 : 0) - (a.active ? 1 : 0)) || (act(b) - act(a)) ||
        String(b.last_print || '').localeCompare(String(a.last_print || '')) || String(a.name).localeCompare(String(b.name), 'he');
    });
  }

  function renderTeam(box, root) {
    var rows = sortRows(st.rows);
    var tot = function (k) { return rows.reduce(function (a, r) { return a + Number(r[k] || 0); }, 0); };
    var neg = rows.filter(function (r) { return Number(r.balance) < 0; }).length;
    var reload = function () { render(root); };
    box.innerHTML =
      '<div class="kpis three"><div class="kpi"><b>' + U.money(tot('credits')) + '</b><span>נטען בסך הכל</span></div>' +
        '<div class="kpi"><b>' + U.money(tot('used')) + '</b><span>הודפס</span></div>' +
        '<div class="kpi' + (neg ? ' bad' : '') + '"><b>' + neg + '</b><span>בלי יתרה</span></div></div>' +
      (canManage() ? '<div class="btn-row"><button class="btn primary" id="prNJ">' + icon('printer') + '<span>הדפסה</span></button>' +
        '<button class="btn" id="prNC">' + icon('coins') + '<span>טעינה</span></button></div>' : '') +
      '<div class="list" id="prTeam">' + (rows.length ? rows.map(function (r) {
        return '<div class="row' + (r.active ? '' : ' dim') + '" data-sid="' + r.staff_id + '">' + U.avatar(r.name) +
          '<div class="grow"><b>' + esc(r.name) + (r.active ? '' : ' <span class="chip mute">לא פעיל</span>') + '</b>' +
          '<div class="meta">' + (r.role_label ? esc(r.role_label) + ' · ' : '') + U.num(r.pages) + ' עמודים' +
            (r.last_print ? ' · אחרונה ' + U.fmtDate(r.last_print) : '') + '</div></div>' +
          '<span class="amt ' + balCls(r.balance) + '">' + U.money(r.balance) + '</span></div>';
      }).join('') : U.empty('users', 'אין צוות פעיל')) + '</div>' +
      pricesLine() +
      '<button class="link-btn" id="prSite">' + icon('external') + 'מחירים, קישור QR ותשלומי נדרים — במסך ההדפסות באתר</button>';
    var byId = function (id) { return rows.filter(function (r) { return String(r.staff_id) === String(id); })[0]; };
    $$('#prTeam .row', box).forEach(function (el) { el.onclick = function () { historySheet(byId(el.dataset.sid), reload); }; });
    if (canManage()) {
      $('#prNJ', box).onclick = function () { jobSheet(null, true, reload); };
      $('#prNC', box).onclick = function () { creditSheet(null, reload); };
    }
    $('#prSite', box).onclick = function () { U.openUrl(App.S.cfg.site); };
  }

  function historySheet(r, reload) {
    var s = U.sheet({
      title: r.name, sub: (r.role_label ? esc(r.role_label) + ' · ' : '') + 'יתרה <b class="amt ' + balCls(r.balance) + '">' + U.money(r.balance) + '</b>',
      wide: true,
      body: (canManage() ? '<div class="btn-row"><button class="btn primary sm" id="hsJ">' + icon('printer') + '<span>הדפסה</span></button>' +
        '<button class="btn sm" id="hsC">' + icon('coins') + '<span>טעינה</span></button></div>' : '') +
        '<div id="hsHist">' + U.loading() + '</div>',
    });
    var done = function () { s.close(); reload(); };
    if (canManage()) {
      $('#hsJ', s.el).onclick = function () { jobSheet(r, true, done); };
      $('#hsC', s.el).onclick = function () { creditSheet(r, done); };
    }
    drawHistory($('#hsHist', s.el), r, canManage(), done);
  }

  // היסטוריה: טעינות והדפסות בציר אחד, עם יתרה מתגלגלת (מהישן לחדש, מוצג מהחדש).
  async function drawHistory(host, r, manage, reload) {
    var inst = App.S.inst, jobs, credits;
    try {
      var res = await Promise.all([Api.q.printJobs(inst, r.staff_id), Api.q.printCredits(inst, r.staff_id)]);
      jobs = res[0] || []; credits = res[1] || [];
    } catch (e) { host.innerHTML = U.empty('x', 'שגיאה בטעינה', esc(e.message)); return; }
    var src = function (j) { return j.source === 'גיליון' ? 'מהגיליון' : j.source === 'קישור' ? 'מהקישור' : ''; };
    var ev = [].concat(
      credits.map(function (c) {
        return { k: 'c', id: c.id, at: c.credited_at, amt: Number(c.amount),
          t: 'טעינה' + (c.source === 'נדרים פלוס' ? ' בנדרים פלוס' : ''), n: c.note || '' };
      }),
      jobs.map(function (j) {
        return { k: 'j', id: j.id, at: j.printed_at, amt: -Number(j.cost),
          t: j.qty + ' × ' + j.size + ' ' + j.color, n: [U.money(j.unit_price) + ' לעמוד', src(j), j.note || ''].filter(Boolean).join(' · ') };
      })
    ).sort(function (a, b) { return String(a.at).localeCompare(String(b.at)) || (a.k === 'c' ? -1 : 1); });
    var run = 0; ev.forEach(function (e) { run += e.amt; e.run = run; });
    ev.reverse();

    // חצי השנה האחרונה — גרף עמודות קטן של הוצאה לחודש
    var months = {};
    jobs.forEach(function (j) { var k = String(j.printed_at).slice(0, 7); months[k] = (months[k] || 0) + Number(j.cost); });
    var mk = Object.keys(months).sort().slice(-6);
    var mx = Math.max.apply(null, mk.map(function (k) { return months[k]; }).concat([0.01]));
    var chart = mk.length ? '<div class="bars" title="הוצאה לחודש">' + mk.map(function (k) {
      return '<div class="bar"><i style="height:' + Math.max(4, Math.round(months[k] / mx * 100)) + '%"></i><b>' + U.money(months[k]).replace('.00', '') + '</b><span>' + k.slice(5) + '/' + k.slice(2, 4) + '</span></div>';
    }).join('') + '</div>' : '';

    host.innerHTML = chart + (ev.length ? '<div class="list tl">' + ev.slice(0, 120).map(function (e) {
      return '<div class="row tl-row">' +
        '<span class="tl-ic ' + (e.k === 'c' ? 'in' : 'out') + '">' + icon(e.k === 'c' ? 'coins' : 'printer') + '</span>' +
        '<div class="grow"><b>' + esc(e.t) + '</b><div class="meta">' + esc(e.k === 'c' ? U.fmtDate(e.at) : U.fmtWhen(e.at)) + (e.n ? ' · ' + esc(e.n) : '') + '</div></div>' +
        '<div class="tl-amt"><span class="' + (e.amt >= 0 ? 'pos' : '') + '">' + U.money(e.amt, true) + '</span>' +
          '<small class="' + balCls(e.run) + '">' + U.money(e.run) + '</small></div>' +
        (manage ? '<button class="ic-btn sm danger" data-del="' + e.k + ':' + e.id + '" title="מחיקה">' + icon('trash') + '</button>' : '') +
        '</div>';
    }).join('') + '</div>' + (ev.length > 120 ? '<div class="hint">מוצגות 120 התנועות האחרונות. הכל — באתר.</div>' : '')
      : U.empty('inbox', 'אין תנועות עדיין'));

    $$('[data-del]', host).forEach(function (b) {
      b.onclick = async function () {
        var p = b.dataset.del.split(':');
        if (!(await U.confirm(p[0] === 'c' ? 'למחוק את הטעינה?' : 'למחוק את ההדפסה?', 'מחיקה', true))) return;
        try { await Api.q.delPrintRow(App.S.inst, p[0] === 'c' ? 'print_credits' : 'print_jobs', p[1]); U.toast('נמחק'); reload(); }
        catch (e) { U.toast('המחיקה נכשלה: ' + e.message, true); }
      };
    });
  }

  function staffSelect(sel) {
    return '<label class="fld full"><span class="lbl">איש צוות <i class="req">*</i></span><select id="prStaff" class="inp">' +
      (sel ? '' : '<option value="">— בחירה —</option>') +
      sortRows(st.rows).filter(function (r) { return r.active || (sel && r.staff_id === sel.staff_id); }).map(function (r) {
        return '<option value="' + r.staff_id + '"' + (sel && r.staff_id === sel.staff_id ? ' selected' : '') + '>' + esc(r.name) + '</option>';
      }).join('') + '</select></label>';
  }

  // דיווח הדפסה. office=true: בוחרים איש צוות ותאריך (מנהל/מזכירה); אחרת — לעצמי.
  function jobSheet(who, office, reload) {
    var s = U.sheet({
      title: 'דיווח הדפסה', sub: office ? '' : esc(who.name),
      body: '<div class="form">' + (office ? staffSelect(who) : '') +
        '<div class="fld full"><span class="lbl">סוג</span>' + U.seg('prColor', COLORS, COLORS[0]) + '</div>' +
        '<div class="fld full"><span class="lbl">גודל דף</span>' + U.seg('prSize', SIZES, SIZES[0]) + '</div>' +
        '<div class="fld full"><span class="lbl">כמות עמודים <i class="req">*</i></span>' +
          '<div class="stepper"><button type="button" class="ic-btn" data-d="-1">' + icon('minus') + '</button>' +
          '<input id="prQty" class="inp num big" type="number" min="1" max="5000" inputmode="numeric" autofocus>' +
          '<button type="button" class="ic-btn" data-d="1">' + icon('plus') + '</button></div>' +
          '<div class="chips">' + [1, 5, 10, 20, 50, 100].map(function (n) { return '<button type="button" class="chip-btn" data-q="' + n + '">' + n + '</button>'; }).join('') + '</div></div>' +
        (office ? U.field('prAt', 'תאריך ושעה', 'datetime-local', { value: U.nowLocal() }) : '') +
        U.field('prNote', 'הערה', 'text', { full: !office, ph: 'לא חובה' }) +
        '<div class="cost full" id="prCost"></div></div>',
      saveLabel: 'רישום ההדפסה',
      onSave: async function (el, api) {
        var sid = office ? Number($('#prStaff', el).value) : who.staff_id;
        var qty = parseInt($('#prQty', el).value, 10);
        if (!sid) { api.msg('יש לבחור איש צוות'); return false; }
        if (!(qty > 0 && qty <= 5000)) { api.msg('כמות לא תקינה (1–5000)'); return false; }
        var row = { staff_id: sid, color: U.segVal(el, 'prColor'), size: U.segVal(el, 'prSize'), qty: qty, source: 'תוכנה' };
        var note = $('#prNote', el).value.trim(); if (note) row.note = note;
        if (office && $('#prAt', el).value) row.printed_at = new Date($('#prAt', el).value).toISOString();
        var out = await Api.q.addPrintJob(App.S.inst, row);
        U.toast('נרשם: ' + U.money(out && out[0] ? out[0].cost : qty * priceOf(row.color, row.size)));
        if (reload) reload();
        return true;
      },
    });
    var el = s.el;
    function cur() {
      if (!office) return who;
      var id = $('#prStaff', el).value;
      return st.rows.filter(function (r) { return String(r.staff_id) === String(id); })[0];
    }
    function upd() {
      var q = parseInt($('#prQty', el).value, 10) || 0;
      var p = priceOf(U.segVal(el, 'prColor'), U.segVal(el, 'prSize'));
      var r = cur();
      $('#prCost', el).innerHTML = q
        ? 'עלות: ' + q + ' × ' + U.money(p) + ' = <b>' + U.money(q * p) + '</b>' + (r ? '<br>היתרה אחרי: <b class="amt ' + balCls(r.balance - q * p) + '">' + U.money(r.balance - q * p) + '</b>' : '')
        : 'מחיר לעמוד: <b>' + U.money(p) + '</b>' + (r ? '<br>יתרה נוכחית: <b class="amt ' + balCls(r.balance) + '">' + U.money(r.balance) + '</b>' : '');
    }
    U.bindSeg(el, upd);
    $('#prQty', el).addEventListener('input', upd);
    if (office) $('#prStaff', el).addEventListener('change', upd);
    $$('[data-d]', el).forEach(function (b) {
      b.onclick = function () { var i = $('#prQty', el); i.value = Math.max(1, (parseInt(i.value, 10) || 0) + Number(b.dataset.d)); upd(); };
    });
    $$('[data-q]', el).forEach(function (b) { b.onclick = function () { $('#prQty', el).value = b.dataset.q; upd(); $('#prQty', el).focus(); }; });
    $('#prQty', el).addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); s.save(); } });
    upd();
  }

  function creditSheet(who, reload) {
    U.sheet({
      title: 'טעינת כסף להדפסות',
      body: '<div class="form">' + staffSelect(who) +
        U.field('prAmt', 'סכום ₪', 'number', { req: true, step: '0.01', hint: 'שלילי = תיקון', inputmode: 'decimal', autofocus: !!who }) +
        U.field('prDate', 'תאריך', 'date', { value: U.today() }) +
        U.field('prCNote', 'הערה', 'text', { full: true, ph: 'למשל: מזומן במזכירות' }) + '</div>',
      saveLabel: 'רישום הטעינה',
      onSave: async function (el, api) {
        var sid = Number($('#prStaff', el).value), amount = Number($('#prAmt', el).value);
        if (!sid) { api.msg('יש לבחור איש צוות'); return false; }
        if (!amount) { api.msg('יש להזין סכום'); return false; }
        var row = { staff_id: sid, amount: amount };
        if ($('#prDate', el).value) row.credited_at = $('#prDate', el).value;
        var note = $('#prCNote', el).value.trim(); if (note) row.note = note;
        await Api.q.addPrintCredit(App.S.inst, row);
        U.toast('הטעינה נרשמה');
        if (reload) reload();
        return true;
      },
    });
  }

  // ================= כרטיס במסך הבית =================
  async function homeCard(host) {
    host.innerHTML = '';
    try { await load(); } catch (e) { return; }
    if (st.err) return;
    var r = myRow();
    if (!r) {
      if (!isOffice()) return;
      var neg = st.rows.filter(function (x) { return Number(x.balance) < 0 && x.active; }).length;
      host.innerHTML = '<div class="tile clickable" id="hpr"><div class="tile-h">' + icon('printer') + '<b>הדפסות הצוות</b><span class="tile-more">לכל היתרות ' + icon('chevL') + '</span></div>' +
        '<div class="tile-b"><div class="meta">' + st.rows.filter(function (x) { return x.active; }).length + ' אנשי צוות' +
        (neg ? ' · <b class="bad">' + neg + ' בלי יתרה</b>' : '') + '</div></div></div>';
      $('#hpr', host).onclick = function () { st.tab = 'team'; App.go('prints'); };
      return;
    }
    var b = Number(r.balance), url = payUrl();
    host.innerHTML = '<div class="tile"><div class="tile-h">' + icon('wallet') + '<b>יתרת ההדפסות שלי</b>' +
      '<button class="tile-more" id="hpAll">היסטוריה ' + icon('chevL') + '</button></div>' +
      '<div class="tile-b bal-row"><span class="bal ' + balCls(b) + '">' + U.money(b) + '</span>' +
      (b < 0 ? '<span class="chip bad">יש לטעון</span>' : '') + '<span class="grow"></span>' +
      '<button class="btn sm primary" id="hpJob">' + icon('printer') + '<span>דיווח הדפסה</span></button>' +
      (url ? '<button class="btn sm" id="hpPay" title="טעינה בנדרים פלוס">' + icon('card') + '<span>טעינה</span></button>' : '') +
      '</div></div>';
    $('#hpAll', host).onclick = function () { st.tab = 'mine'; App.go('prints'); };
    $('#hpJob', host).onclick = function () { jobSheet(r, false, function () { homeCard(host); }); };
    if (url) $('#hpPay', host).onclick = function () { U.openUrl(url); };
  }

  // דיווח הדפסה ישירות (מהכפתור המהיר במסך הבית)
  async function quickJob(onDone) {
    if (!st.rows.length) { try { await load(); } catch (e) { /* מטופל למטה */ } }
    var r = myRow();
    if (r) return jobSheet(r, false, onDone);
    if (canManage()) return jobSheet(null, true, onDone);
    U.toast(st.err ? 'מסך ההדפסות לא זמין' : 'המשתמש שלך לא מקושר לאיש צוות', true);
  }

  return { render: render, homeCard: homeCard, quickJob: quickJob, nedarimUrl: nedarimUrl };
})();
